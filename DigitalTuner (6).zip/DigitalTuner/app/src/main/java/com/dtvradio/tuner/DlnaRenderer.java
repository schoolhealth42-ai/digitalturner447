package com.dtvradio.tuner;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Receiver mode: this device becomes a DLNA "Media Renderer" on the Wi-Fi network.
 * Install the app on an Android satellite receiver, Android TV box, smart TV or a second phone,
 * enable receiver mode, and channels can be sent to it from a phone (this app, or any DLNA app).
 */
public final class DlnaRenderer {
    private DlnaRenderer() {}

    static final String AVT = "urn:schemas-upnp-org:service:AVTransport:1";
    static final String RCS = "urn:schemas-upnp-org:service:RenderingControl:1";
    static final String CMS = "urn:schemas-upnp-org:service:ConnectionManager:1";
    static final String DEVICE = "urn:schemas-upnp-org:device:MediaRenderer:1";

    private static final ExecutorService EX = Executors.newCachedThreadPool();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static volatile boolean running = false;
    private static ServerSocket server;
    private static MulticastSocket ssdp;
    private static WifiManager.MulticastLock lock;
    private static Context app;
    private static volatile int port = 0;
    private static volatile String ip, uuid, name;

    static volatile String state = "NO_MEDIA_PRESENT";
    static volatile String currentUri = "";
    static volatile String currentMeta = "";
    static volatile String currentTitle = "";

    public interface StatusListener { void onRendererStatus(boolean running, String address); }
    private static StatusListener statusListener;

    public static void setStatusListener(StatusListener l) { statusListener = l; }
    public static boolean isRunning() { return running && port > 0; }
    public static String address() { return ip == null ? "" : ip + ":" + port; }
    public static String deviceName() { return name == null ? "" : name; }

    public static String defaultName() {
        return "الموالف الرقمي - " + Build.MODEL;
    }

    public static synchronized void start(Context c) {
        if (running) return;
        app = c.getApplicationContext();
        uuid = Prefs.p(app).getString("rcv_uuid", null);
        if (uuid == null) {
            uuid = UUID.randomUUID().toString();
            Prefs.edit(app).putString("rcv_uuid", uuid).apply();
        }
        String n = Prefs.p(app).getString("rcv_name", "");
        name = n.trim().isEmpty() ? defaultName() : n.trim();
        running = true;
        EX.execute(DlnaRenderer::boot);
    }

    public static synchronized void stop() {
        if (!running) return;
        running = false;
        EX.execute(() -> sendNotify("ssdp:byebye"));
        try { if (server != null) server.close(); } catch (Exception ignored) {}
        try { if (ssdp != null) ssdp.close(); } catch (Exception ignored) {}
        try { if (lock != null) lock.release(); } catch (Exception ignored) {}
        port = 0;
        fireStatus();
    }

    private static void fireStatus() {
        final boolean r = isRunning();
        final String addr = address();
        MAIN.post(() -> { if (statusListener != null) statusListener.onRendererStatus(r, addr); });
    }

    private static void boot() {
        ip = localIp();
        if (ip == null) {
            running = false;
            fireStatus();
            return;
        }
        server = null;
        for (int p = 49200; p < 49230 && server == null; p++) {
            try { server = new ServerSocket(p); port = p; } catch (IOException ignored) {}
        }
        if (server == null) {
            running = false;
            fireStatus();
            return;
        }
        try {
            WifiManager wm = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                lock = wm.createMulticastLock("dlna-renderer");
                lock.setReferenceCounted(false);
                lock.acquire();
            }
        } catch (Exception ignored) {}
        EX.execute(DlnaRenderer::ssdpLoop);
        EX.execute(DlnaRenderer::notifyLoop);
        fireStatus();
        ServerSocket s = server;
        while (running) {
            try {
                final Socket sock = s.accept();
                EX.execute(() -> handle(sock));
            } catch (IOException e) {
                if (!running) break;
            }
        }
        try { s.close(); } catch (Exception ignored) {}
        server = null;
    }

    static String localIp() {
        try {
            String fallback = null;
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (!(a instanceof Inet4Address) || a.isLoopbackAddress()) continue;
                    String n = ni.getName().toLowerCase(Locale.ROOT);
                    if (a.isSiteLocalAddress() && (n.startsWith("wlan") || n.startsWith("eth") || n.startsWith("ap"))) {
                        return a.getHostAddress();
                    }
                    if (a.isSiteLocalAddress() && fallback == null) fallback = a.getHostAddress();
                }
            }
            return fallback;
        } catch (Exception e) {
            return null;
        }
    }

    // ===================== SSDP =====================

    private static String[] types() {
        return new String[]{"upnp:rootdevice", "uuid:" + uuid, DEVICE, AVT, RCS, CMS};
    }

    private static String usn(String st) {
        return st.startsWith("uuid:") ? "uuid:" + uuid : "uuid:" + uuid + "::" + st;
    }

    private static void ssdpLoop() {
        try {
            ssdp = new MulticastSocket(1900);
            ssdp.joinGroup(InetAddress.getByName(Dlna.GROUP));
            byte[] buf = new byte[4096];
            while (running) {
                DatagramPacket p = new DatagramPacket(buf, buf.length);
                ssdp.receive(p);
                String msg = new String(p.getData(), 0, p.getLength(), "UTF-8");
                if (!msg.startsWith("M-SEARCH")) continue;
                String st = Dlna.header(msg, "ST");
                if (st == null) continue;
                List<String> answer = new ArrayList<>();
                if (st.equals("ssdp:all")) {
                    Collections.addAll(answer, types());
                } else {
                    for (String t : types()) if (t.equalsIgnoreCase(st)) answer.add(t);
                }
                for (String t : answer) {
                    String r = "HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nEXT:\r\n"
                            + "LOCATION: http://" + ip + ":" + port + "/desc.xml\r\n"
                            + "SERVER: Android/" + Build.VERSION.RELEASE + " UPnP/1.0 DigitalTuner/3.2\r\n"
                            + "ST: " + t + "\r\nUSN: " + usn(t) + "\r\n\r\n";
                    byte[] b = r.getBytes("UTF-8");
                    ssdp.send(new DatagramPacket(b, b.length, p.getAddress(), p.getPort()));
                }
            }
        } catch (Exception ignored) {
        } finally {
            try { if (ssdp != null) ssdp.close(); } catch (Exception ignored) {}
        }
    }

    private static void notifyLoop() {
        while (running) {
            sendNotify("ssdp:alive");
            try { Thread.sleep(30_000); } catch (InterruptedException e) { return; }
        }
    }

    private static void sendNotify(String nts) {
        DatagramSocket s = null;
        try {
            s = new DatagramSocket();
            InetAddress group = InetAddress.getByName(Dlna.GROUP);
            for (String t : types()) {
                String m = "NOTIFY * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nCACHE-CONTROL: max-age=1800\r\n"
                        + "LOCATION: http://" + ip + ":" + port + "/desc.xml\r\nNT: " + t + "\r\nNTS: " + nts + "\r\n"
                        + "SERVER: Android UPnP/1.0 DigitalTuner/3.2\r\nUSN: " + usn(t) + "\r\n\r\n";
                byte[] b = m.getBytes("UTF-8");
                s.send(new DatagramPacket(b, b.length, group, 1900));
            }
        } catch (Exception ignored) {
        } finally {
            if (s != null) s.close();
        }
    }

    // ===================== HTTP =====================

    private static String readLine(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') b.write(c);
        }
        if (c == -1 && b.size() == 0) return null;
        return b.toString("UTF-8");
    }

    private static void handle(Socket sock) {
        try {
            sock.setSoTimeout(10_000);
            InputStream in = sock.getInputStream();
            String req = readLine(in);
            if (req == null) return;
            Map<String, String> headers = new HashMap<>();
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                int i = line.indexOf(':');
                if (i > 0) headers.put(line.substring(0, i).trim().toLowerCase(Locale.ROOT), line.substring(i + 1).trim());
            }
            int len = 0;
            try { len = Integer.parseInt(headers.containsKey("content-length") ? headers.get("content-length") : "0"); } catch (Exception ignored) {}
            byte[] body = new byte[Math.max(0, Math.min(len, 1_000_000))];
            int off = 0;
            while (off < body.length) {
                int n = in.read(body, off, body.length - off);
                if (n < 0) break;
                off += n;
            }
            String[] parts = req.split(" ");
            String method = parts.length > 0 ? parts[0] : "";
            String path = parts.length > 1 ? parts[1] : "/";
            OutputStream out = sock.getOutputStream();

            if (method.equals("GET") || method.equals("HEAD")) {
                String xml = null;
                if (path.startsWith("/desc.xml")) xml = descXml();
                else if (path.startsWith("/AVTransport.xml")) xml = Scpd.avTransport();
                else if (path.startsWith("/RenderingControl.xml")) xml = Scpd.renderingControl();
                else if (path.startsWith("/ConnectionManager.xml")) xml = Scpd.connectionManager();
                if (xml == null) respond(out, "404 Not Found", "text/plain", "");
                else respond(out, "200 OK", "text/xml; charset=\"utf-8\"", xml);
            } else if (method.equals("POST")) {
                String action = headers.get("soapaction");
                if (action == null) action = "";
                action = action.replace("\"", "");
                int hash = action.indexOf('#');
                String service = hash > 0 ? action.substring(0, hash) : AVT;
                String act = hash > 0 ? action.substring(hash + 1) : "";
                String result = soap(act, new String(body, 0, off, "UTF-8"));
                String env = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                        + "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
                        + "<s:Body><u:" + act + "Response xmlns:u=\"" + service + "\">" + result + "</u:" + act + "Response></s:Body></s:Envelope>";
                respond(out, "200 OK", "text/xml; charset=\"utf-8\"", env);
            } else if (method.equals("SUBSCRIBE")) {
                String head = "HTTP/1.1 200 OK\r\nSID: uuid:" + UUID.randomUUID() + "\r\nTIMEOUT: Second-1800\r\n"
                        + "Content-Length: 0\r\nConnection: close\r\n\r\n";
                out.write(head.getBytes("UTF-8"));
                out.flush();
            } else if (method.equals("UNSUBSCRIBE")) {
                respond(out, "200 OK", "text/plain", "");
            } else {
                respond(out, "405 Method Not Allowed", "text/plain", "");
            }
        } catch (Exception ignored) {
        } finally {
            try { sock.close(); } catch (Exception ignored) {}
        }
    }

    private static void respond(OutputStream out, String status, String type, String body) throws IOException {
        byte[] b = body.getBytes("UTF-8");
        String head = "HTTP/1.1 " + status + "\r\nContent-Type: " + type + "\r\nContent-Length: " + b.length
                + "\r\nServer: Android UPnP/1.0 DigitalTuner/3.2\r\nConnection: close\r\n\r\n";
        out.write(head.getBytes("UTF-8"));
        out.write(b);
        out.flush();
    }

    private static String descXml() {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<root xmlns=\"urn:schemas-upnp-org:device-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion>"
                + "<device><deviceType>" + DEVICE + "</deviceType>"
                + "<friendlyName>" + Dlna.esc(name) + "</friendlyName>"
                + "<manufacturer>DigitalTuner</manufacturer><modelName>Digital Tuner Receiver</modelName>"
                + "<modelNumber>3.2</modelNumber><UDN>uuid:" + uuid + "</UDN><serviceList>"
                + service(AVT, "AVTransport") + service(RCS, "RenderingControl") + service(CMS, "ConnectionManager")
                + "</serviceList></device></root>";
    }

    private static String service(String type, String id) {
        return "<service><serviceType>" + type + "</serviceType><serviceId>urn:upnp-org:serviceId:" + id + "</serviceId>"
                + "<SCPDURL>/" + id + ".xml</SCPDURL><controlURL>/" + id + "/control</controlURL>"
                + "<eventSubURL>/" + id + "/event</eventSubURL></service>";
    }

    // ===================== actions =====================

    private static String el(String n, String v) { return "<" + n + ">" + Dlna.esc(v) + "</" + n + ">"; }

    private static String soap(String act, String body) {
        AudioManager am = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
        switch (act) {
            case "SetAVTransportURI": {
                String uri = Dlna.tag(body, "CurrentURI");
                String meta = Dlna.tag(body, "CurrentURIMetaData");
                currentUri = uri == null ? "" : uri;
                currentMeta = meta == null ? "" : meta;
                String t = meta == null ? null : Dlna.tag(meta, "title");
                currentTitle = t == null ? "" : t;
                state = "STOPPED";
                // most senders follow with Play; some never do, so start shortly anyway
                final String u = currentUri;
                MAIN.postDelayed(() -> {
                    if (u.equals(currentUri) && "STOPPED".equals(state)) startPlayback();
                }, 2500);
                return "";
            }
            case "Play":
                MAIN.post(DlnaRenderer::startPlayback);
                return "";
            case "Pause":
                state = "PAUSED_PLAYBACK";
                MAIN.post(() -> PlayerActivity.remotePause());
                return "";
            case "Stop":
                state = "STOPPED";
                MAIN.post(() -> PlayerActivity.remoteClose());
                return "";
            case "Seek":
            case "SetNextAVTransportURI":
            case "SetPlayMode":
                return "";
            case "GetTransportInfo":
                return el("CurrentTransportState", state) + el("CurrentTransportStatus", "OK") + el("CurrentSpeed", "1");
            case "GetPositionInfo":
                return el("Track", "1") + el("TrackDuration", "00:00:00") + el("TrackMetaData", currentMeta)
                        + el("TrackURI", currentUri) + el("RelTime", "00:00:00") + el("AbsTime", "00:00:00")
                        + el("RelCount", "2147483647") + el("AbsCount", "2147483647");
            case "GetMediaInfo":
                return el("NrTracks", currentUri.isEmpty() ? "0" : "1") + el("MediaDuration", "00:00:00")
                        + el("CurrentURI", currentUri) + el("CurrentURIMetaData", currentMeta)
                        + el("NextURI", "") + el("NextURIMetaData", "") + el("PlayMedium", "NETWORK")
                        + el("RecordMedium", "NOT_IMPLEMENTED") + el("WriteStatus", "NOT_IMPLEMENTED");
            case "GetTransportSettings":
                return el("PlayMode", "NORMAL") + el("RecQualityMode", "NOT_IMPLEMENTED");
            case "GetCurrentTransportActions":
                return el("Actions", "Play,Stop,Pause");
            case "GetDeviceCapabilities":
                return el("PlayMedia", "NETWORK") + el("RecMedia", "NOT_IMPLEMENTED") + el("RecQualityModes", "NOT_IMPLEMENTED");
            case "GetVolume": {
                int v = 50;
                if (am != null) {
                    int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                    v = max > 0 ? Math.round(100f * am.getStreamVolume(AudioManager.STREAM_MUSIC) / max) : 50;
                }
                return el("CurrentVolume", String.valueOf(v));
            }
            case "SetVolume": {
                String dv = Dlna.tag(body, "DesiredVolume");
                if (am != null && dv != null) {
                    try {
                        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                        int v = Math.round(Integer.parseInt(dv.trim()) * max / 100f);
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(0, Math.min(max, v)), 0);
                    } catch (Exception ignored) {}
                }
                return "";
            }
            case "GetMute":
                return el("CurrentMute", "0");
            case "SetMute":
                return "";
            case "GetProtocolInfo":
                return el("Source", "") + el("Sink",
                        "http-get:*:video/mp4:*,http-get:*:video/mp2t:*,http-get:*:application/vnd.apple.mpegurl:*,"
                                + "http-get:*:application/x-mpegurl:*,http-get:*:audio/mpeg:*,http-get:*:audio/aac:*,http-get:*:*:*");
            case "GetCurrentConnectionIDs":
                return el("ConnectionIDs", "0");
            case "GetCurrentConnectionInfo":
                return el("RcsID", "0") + el("AVTransportID", "0") + el("ProtocolInfo", "")
                        + el("PeerConnectionManager", "") + el("PeerConnectionID", "-1")
                        + el("Direction", "Input") + el("Status", "OK");
            default:
                return "";
        }
    }

    /** Opens (or resumes) the player with the received stream. */
    private static void startPlayback() {
        if (currentUri.isEmpty()) return;
        state = "PLAYING";
        if (PlayerActivity.remoteResumeIfSame(currentUri)) return;
        Station s = new Station();
        s.url = currentUri;
        s.name = currentTitle.isEmpty() ? "📡 بث من جهاز آخر" : currentTitle;
        s.band = "TV";
        List<Station> l = new ArrayList<>();
        l.add(s);
        PlayerActivity.playlist = l;
        PlayerActivity.index = 0;
        AudioPlayer.get().stop();
        try {
            Intent i = new Intent(app, PlayerActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            app.startActivity(i);
        } catch (Exception ignored) {}
    }
}
