package com.dtvradio.tuner;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

/**
 * Background HTTP GET helper with a small disk cache for channel lists.
 * Cached lists open instantly and still work when the connection drops
 * (a stale copy is used if the network fails). Callbacks run on the main thread.
 */
public final class Net {
    private Net() {}

    public interface Callback {
        void ok(String body);
        void err(String message);
    }

    /** Converts downloaded bodies into a result, on a background thread. A failed URL gives null. */
    public interface Transform<T> {
        T apply(List<String> bodies);
    }

    public interface Result<T> {
        void done(T value, int failed);
    }

    private static final ExecutorService EX = Executors.newFixedThreadPool(4);
    private static final ExecutorService DL = Executors.newFixedThreadPool(4);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private static File cacheDir;
    private static volatile long ttlMs = 6 * 3600_000L;

    public static void init(Context c) {
        cacheDir = new File(c.getCacheDir(), "lists");
        if (!cacheDir.exists()) cacheDir.mkdirs();
        ttlMs = Prefs.cacheHours(c) * 3600_000L;
    }

    /** Tries each URL in turn until one succeeds. */
    public static void get(final String[] urls, final Callback cb) {
        EX.execute(() -> {
            Exception last = null;
            for (String u : urls) {
                try {
                    final String body = fetchCached(u);
                    MAIN.post(() -> cb.ok(body));
                    return;
                } catch (Exception e) {
                    last = e;
                }
            }
            final String msg = last == null ? "error" : last.getMessage();
            MAIN.post(() -> cb.err(msg));
        });
    }

    public static void get(String url, Callback cb) {
        get(new String[]{url}, cb);
    }

    /** Downloads all URLs in parallel (same order, null for failures), transforms in background. */
    public static <T> void getAll(final String[] urls, final Transform<T> tf, final Result<T> cb) {
        EX.execute(() -> {
            List<Future<String>> fs = new ArrayList<>();
            for (final String u : urls) fs.add(DL.submit(() -> fetchCached(u)));
            List<String> bodies = new ArrayList<>();
            int failed = 0;
            for (Future<String> f : fs) {
                try {
                    bodies.add(f.get());
                } catch (Exception e) {
                    bodies.add(null);
                    failed++;
                }
            }
            T value = null;
            try {
                value = tf.apply(bodies);
            } catch (Exception ignored) {}
            final T v = value;
            final int fl = failed;
            MAIN.post(() -> cb.done(v, fl));
        });
    }

    // ---------------- cache ----------------

    private static File cacheFile(String u) {
        if (cacheDir == null) return null;
        return new File(cacheDir, Integer.toHexString(u.hashCode()) + "_" + u.length() + ".txt");
    }

    static String fetchCached(String u) throws IOException {
        File f = cacheFile(u);
        long ttl = ttlMs;
        if (f != null && ttl > 0 && f.exists() && System.currentTimeMillis() - f.lastModified() < ttl) {
            try { return readFile(f); } catch (IOException ignored) {}
        }
        try {
            String body = fetch(u);
            if (f != null && ttl > 0) {
                try { writeFile(f, body); } catch (IOException ignored) {}
            }
            return body;
        } catch (IOException e) {
            if (f != null && f.exists()) return readFile(f);   // offline: use the old copy
            throw e;
        }
    }

    public static long cacheSize() {
        long n = 0;
        if (cacheDir == null) return 0;
        File[] fs = cacheDir.listFiles();
        if (fs != null) for (File f : fs) n += f.length();
        return n;
    }

    public static void clearCache() {
        if (cacheDir == null) return;
        File[] fs = cacheDir.listFiles();
        if (fs != null) for (File f : fs) f.delete();
    }

    private static String readFile(File f) throws IOException {
        FileInputStream in = new FileInputStream(f);
        try {
            return new String(readAll(in, Integer.MAX_VALUE), "UTF-8");
        } finally {
            in.close();
        }
    }

    private static void writeFile(File f, String s) throws IOException {
        FileOutputStream out = new FileOutputStream(f);
        try {
            out.write(s.getBytes("UTF-8"));
        } finally {
            out.close();
        }
    }

    // ---------------- network ----------------

    static byte[] readAll(InputStream in, int limit) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        while ((n = in.read(buf)) > 0) {
            bo.write(buf, 0, n);
            if (bo.size() > limit) throw new IOException("too large");
        }
        return bo.toByteArray();
    }

    static HttpURLConnection open(String u) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "DigitalTuner/3.0 (Android)");
        return c;
    }

    static String fetch(String u) throws IOException {
        HttpURLConnection c = open(u);
        int code = c.getResponseCode();
        if (code >= 400) throw new IOException("HTTP " + code);
        InputStream in = c.getInputStream();
        try {
            return new String(readAll(in, Integer.MAX_VALUE), "UTF-8");
        } finally {
            in.close();
            c.disconnect();
        }
    }

    static byte[] fetchBytes(String u, int limit) throws IOException {
        HttpURLConnection c = open(u);
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        int code = c.getResponseCode();
        if (code >= 400) throw new IOException("HTTP " + code);
        InputStream in = c.getInputStream();
        try {
            return readAll(in, limit);
        } finally {
            in.close();
            c.disconnect();
        }
    }
}
