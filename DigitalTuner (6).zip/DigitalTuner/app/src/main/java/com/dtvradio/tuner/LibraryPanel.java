package com.dtvradio.tuner;

import android.app.AlertDialog;
import android.content.Intent;
import android.text.TextUtils;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/** "My library": continue watching, recently watched / heard, favorite channels and stations. */
public class LibraryPanel extends LinearLayout {
    static final String[] MODES = {"🕘 شاهدتها مؤخراً", "🎧 استمعت مؤخراً", "★ قنواتي", "★ محطاتي"};

    private final MainActivity a;
    private final StationAdapter tvAdapter, radioAdapter;
    private final ListView list;
    private final Button[] modeBtns = new Button[MODES.length];
    private final TextView emptyTv, heroTitle, heroSub;
    private final LinearLayout hero;
    private int mode = 0;

    public LibraryPanel(MainActivity act) {
        super(act);
        a = act;
        tvAdapter = new StationAdapter(act, "tv");
        radioAdapter = new StationAdapter(act, "radio");
        setOrientation(VERTICAL);
        int p = Ui.dp(act, 12);
        setPadding(p, p / 2, p, 0);

        // "continue" card
        hero = Ui.card(act);
        hero.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR, new int[]{Ui.ACCENT, Ui.CARD2}));
        ((android.graphics.drawable.GradientDrawable) hero.getBackground()).setCornerRadius(Ui.dp(act, 18));
        heroSub = Ui.text(act, "▶ تابع من حيث توقفت", 13, Ui.TEXT, false);
        heroTitle = Ui.text(act, "", 20, Ui.TEXT, true);
        heroTitle.setSingleLine(true);
        heroTitle.setEllipsize(TextUtils.TruncateAt.END);
        hero.addView(heroSub);
        hero.addView(heroTitle, Ui.full(act, 4));
        hero.setOnClickListener(v -> continueLast());
        addView(hero);

        HorizontalScrollView hs = new HorizontalScrollView(act);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout row = Ui.row(act);
        for (int i = 0; i < MODES.length; i++) {
            final int idx = i;
            Button b = Ui.chipButton(act, MODES[i]);
            b.setOnClickListener(v -> setMode(idx));
            modeBtns[i] = b;
            row.addView(b, Ui.wrap(act, 2));
        }
        Button clear = Ui.chipButton(act, "🗑 مسح");
        clear.setOnClickListener(v -> clearCurrent());
        row.addView(clear, Ui.wrap(act, 2));
        hs.addView(row);
        addView(hs, Ui.full(act, 8));

        emptyTv = Ui.text(act, "", 14, Ui.SUB, false);
        emptyTv.setPadding(Ui.dp(act, 8), Ui.dp(act, 16), Ui.dp(act, 8), 0);
        addView(emptyTv);

        list = new ListView(act);
        list.setDivider(null);
        list.setOnItemClickListener((parent, view, pos, id) -> open(pos));
        list.setOnItemLongClickListener((parent, view, pos, id) -> {
            removeAt(pos);
            return true;
        });
        addView(list, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    public void onShown() {
        setMode(mode);
        refreshHero();
    }

    private boolean isTv() { return mode == 0 || mode == 2; }

    private List<Station> data() {
        switch (mode) {
            case 0: return History.load(a, "tv");
            case 1: return History.load(a, "radio");
            case 2: return Favorites.load(a, "tv");
            default: return Favorites.load(a, "radio");
        }
    }

    private void setMode(int m) {
        mode = m;
        for (int i = 0; i < modeBtns.length; i++) Ui.chip(a, modeBtns[i], i == m);
        StationAdapter ad = isTv() ? tvAdapter : radioAdapter;
        ad.setData(data());
        list.setAdapter(ad);
        String[] empty = {
                "لم تشاهد أي قناة بعد — ستظهر هنا آخر القنوات التي شاهدتها",
                "لم تستمع لأي محطة بعد",
                "لا توجد قنوات مفضلة — اضغط مطولاً على أي قناة في «تلفاز»",
                "لا توجد محطات مفضلة — اضغط مطولاً على أي محطة في «راديو»"};
        emptyTv.setText(empty[m]);
        emptyTv.setVisibility(ad.getCount() == 0 ? VISIBLE : GONE);
    }

    private void refreshHero() {
        List<Station> tv = History.load(a, "tv");
        if (tv.isEmpty()) {
            hero.setVisibility(GONE);
            return;
        }
        hero.setVisibility(VISIBLE);
        heroTitle.setText("📺 " + tv.get(0).name);
    }

    private void continueLast() {
        List<Station> tv = History.load(a, "tv");
        if (tv.isEmpty()) return;
        PlayerActivity.playlist = new ArrayList<>(tv);
        PlayerActivity.index = 0;
        a.startActivity(new Intent(a, PlayerActivity.class));
    }

    private void open(int pos) {
        StationAdapter ad = isTv() ? tvAdapter : radioAdapter;
        List<Station> shown = ad.shown();
        if (pos < 0 || pos >= shown.size()) return;
        if (isTv()) {
            PlayerActivity.playlist = new ArrayList<>(shown);
            PlayerActivity.index = pos;
            a.startActivity(new Intent(a, PlayerActivity.class));
        } else {
            a.playRadio(shown.get(pos));
        }
    }

    private void removeAt(final int pos) {
        StationAdapter ad = isTv() ? tvAdapter : radioAdapter;
        final Station s = ad.shown().get(pos);
        new AlertDialog.Builder(a)
                .setTitle(s.name)
                .setItems(new String[]{"🗑 إزالة من هذه القائمة"}, (d, w) -> {
                    if (mode == 0) History.remove(a, "tv", s.url);
                    else if (mode == 1) History.remove(a, "radio", s.url);
                    else Favorites.toggle(a, mode == 2 ? "tv" : "radio", s);
                    setMode(mode);
                    refreshHero();
                }).show();
    }

    private void clearCurrent() {
        if (mode > 1) {
            Toast.makeText(a, "لإزالة عنصر من المفضلة اضغط عليه مطولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        new AlertDialog.Builder(a)
                .setMessage("مسح " + (mode == 0 ? "سجل المشاهدة" : "سجل الاستماع") + "؟")
                .setPositiveButton("مسح", (d, w) -> {
                    Favorites.save(a, mode == 0 ? "hist_tv" : "hist_radio", new ArrayList<Station>());
                    setMode(mode);
                    refreshHero();
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }
}
