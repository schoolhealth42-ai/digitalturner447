package com.dtvradio.tuner;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Small helpers to build a consistent dark UI in code (no XML layouts). */
public final class Ui {
    public static int BG = 0xFF0B1220;
    public static int CARD = 0xFF141E30;
    public static int CARD2 = 0xFF1C2940;
    public static int ACCENT = 0xFF22C3EE;
    /** Text size multiplier (small / normal / large). */
    public static float SCALE = 1f;

    public static final int[] ACCENTS = {0xFF22C3EE, 0xFF22C55E, 0xFFF5A524, 0xFFEC4899, 0xFFA855F7, 0xFFEF4444, 0xFF3B82F6};
    public static final String[] ACCENT_NAMES = {"سماوي", "أخضر", "ذهبي", "وردي", "بنفسجي", "أحمر", "أزرق"};

    /** Reads the appearance settings; call before building any view. */
    public static void applyTheme(Context c) {
        int i = Prefs.accent(c);
        ACCENT = ACCENTS[(i >= 0 && i < ACCENTS.length) ? i : 0];
        if (Prefs.amoled(c)) {
            BG = 0xFF000000; CARD = 0xFF0D0D0D; CARD2 = 0xFF1A1A1A;
        } else {
            BG = 0xFF0B1220; CARD = 0xFF141E30; CARD2 = 0xFF1C2940;
        }
        int f = Prefs.fontSize(c);
        SCALE = f == 0 ? 0.9f : f == 2 ? 1.15f : 1f;
    }
    public static final int ACCENT2 = 0xFFF5A524;
    public static final int TEXT = 0xFFF1F5F9;
    public static final int SUB = 0xFF94A3B8;
    public static final int GREEN = 0xFF22C55E;
    public static final int RED = 0xFFEF4444;
    public static final int DARK_TEXT = 0xFF04131A;

    private Ui() {}

    public static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static GradientDrawable round(Context c, int color, float radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp * SCALE);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    public static Button button(Context c, String s, int bg) {
        Button b = new Button(c);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(15 * SCALE);
        b.setTextColor(bg == ACCENT || bg == ACCENT2 || bg == GREEN ? DARK_TEXT : TEXT);
        b.setBackground(round(c, bg, 12));
        b.setPadding(dp(c, 12), dp(c, 6), dp(c, 12), dp(c, 6));
        b.setMinHeight(0);
        b.setMinimumHeight(dp(c, 44));
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setStateListAnimator(null);
        b.setGravity(Gravity.CENTER);
        return b;
    }

    public static void chip(Context c, Button b, boolean on) {
        b.setBackground(round(c, on ? ACCENT : CARD2, 20));
        b.setTextColor(on ? DARK_TEXT : TEXT);
    }

    public static Button chipButton(Context c, String s) {
        Button b = button(c, s, CARD2);
        b.setTextSize(14 * SCALE);
        b.setMinimumHeight(dp(c, 38));
        b.setPadding(dp(c, 16), 0, dp(c, 16), 0);
        chip(c, b, false);
        return b;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(round(c, CARD, 16));
        int p = dp(c, 14);
        l.setPadding(p, p, p, p);
        return l;
    }

    public static LinearLayout row(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    public static LinearLayout.LayoutParams lp(int w, int h) {
        return new LinearLayout.LayoutParams(w, h);
    }

    public static LinearLayout.LayoutParams weight(Context c, float w, int marginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w);
        int m = dp(c, marginDp);
        p.setMargins(m, m, m, m);
        return p;
    }

    public static LinearLayout.LayoutParams full(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = dp(c, topDp);
        return p;
    }

    public static LinearLayout.LayoutParams wrap(Context c, int marginDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        int m = dp(c, marginDp);
        p.setMargins(m, m, m, m);
        return p;
    }
}
