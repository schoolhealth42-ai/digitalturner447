package com.dtvradio.tuner;

import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Internet radio grouped as FM / AM / SW bands (radio-browser.info directory). */
public class RadioPanel extends LinearLayout implements AudioPlayer.Listener {
    static final String[] SERVERS = {
            "https://all.api.radio-browser.info",
            "https://de1.api.radio-browser.info",
            "https://de2.api.radio-browser.info",
            "https://fi1.api.radio-browser.info"
    };
    static final String[] BANDS = {"FM", "AM", "SW", "★"};

    private final MainActivity a;
    private final StationAdapter adapter;
    private final Button[] chips = new Button[BANDS.length];
    private final TextView bandTv, nameTv, infoTv, statusTv, countTv;
    private final Button playBtn, favBtn, sleepBtn;
    private final ProgressBar loading;
    private String band = "FM";
    private int index = -1;
    private int seq = 0;
    private boolean loadedOnce = false;

    // ---- filters: country / language / content + sort ----
    static final String[][] LANGS = {
            {"", "كل اللغات"}, {"arabic", "العربية"}, {"english", "الإنجليزية"}, {"french", "الفرنسية"},
            {"turkish", "التركية"}, {"urdu", "الأردية"}, {"persian", "الفارسية"}, {"hindi", "الهندية"},
            {"bengali", "البنغالية"}, {"indonesian", "الإندونيسية"}, {"malay", "الملايوية"}, {"kurdish", "الكردية"},
            {"spanish", "الإسبانية"}, {"portuguese", "البرتغالية"}, {"german", "الألمانية"},
            {"italian", "الإيطالية"}, {"russian", "الروسية"}
    };
    static final String[][] TAGS = {
            {"", "كل المحتوى"}, {"quran", "📖 قرآن كريم"}, {"islamic", "🕌 إسلامي"}, {"news", "📰 أخبار"},
            {"talk", "🎙 برامج حوارية"}, {"sports", "⚽ رياضة"}, {"music", "🎵 موسيقى"}, {"pop", "🎤 بوب"},
            {"arabic music", "🪕 موسيقى عربية"}, {"khaleeji", "🌴 خليجي"}, {"classical", "🎻 كلاسيكي"},
            {"oldies", "📻 قديم"}, {"jazz", "🎷 جاز"}, {"rock", "🎸 روك"}, {"chillout", "🌙 هادئ"},
            {"kids", "🧸 أطفال"}, {"culture", "🏛 ثقافة"}, {"education", "🎓 تعليم"}, {"traditional", "🏺 تراثي"}
    };
    static final String[][] SORTS = {
            {"clickcount", "true", "🔥 الأكثر استماعاً"}, {"votes", "true", "👍 الأعلى تقييماً"},
            {"name", "false", "🔤 أبجدياً"}, {"bitrate", "true", "🎧 الأعلى جودة"},
            {"bitrate", "false", "⚡ الأخف (نت ضعيف)"}
    };

    private String fCountry, fCountryName, fLang, fLangName, fTag, fTagName;
    private int fSort;
    private Button countryBtn, langBtn, tagBtn, sortBtn;
    private LinearLayout filterBar;
    /** AM / SW lists are small: if a country has none, show the whole world instead. */
    private boolean anyCountry = false;

    interface Picked { void on(int which); }

    public RadioPanel(MainActivity act) {
        super(act);
        a = act;
        adapter = new StationAdapter(act, "radio");
        setOrientation(VERTICAL);
        int p = Ui.dp(act, 12);
        setPadding(p, p / 2, p, 0);

        // ---- dial display ----
        LinearLayout dial = Ui.card(act);
        dial.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                new int[]{Ui.CARD2, Ui.BG}));
        ((android.graphics.drawable.GradientDrawable) dial.getBackground()).setCornerRadius(Ui.dp(act, 18));
        LinearLayout top = Ui.row(act);
        bandTv = Ui.text(act, "FM", 13, Ui.DARK_TEXT, true);
        bandTv.setBackground(Ui.round(act, Ui.ACCENT2, 8));
        bandTv.setPadding(Ui.dp(act, 10), Ui.dp(act, 2), Ui.dp(act, 10), Ui.dp(act, 2));
        top.addView(bandTv);
        statusTv = Ui.text(act, "اختر محطة", 13, Ui.SUB, false);
        statusTv.setPadding(Ui.dp(act, 10), 0, 0, 0);
        top.addView(statusTv, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f));
        Button castBtn = Ui.chipButton(act, "📡 عرض");
        castBtn.setTextSize(12 * Ui.SCALE);
        castBtn.setMinimumHeight(Ui.dp(act, 30));
        castBtn.setOnClickListener(v -> {
            if (CastManager.isCasting()) {
                CastManager.stopCasting(a);
                Toast.makeText(a, "أُوقف العرض على الشاشة الأخرى", Toast.LENGTH_SHORT).show();
                return;
            }
            Station cur = AudioPlayer.get().current();
            CastManager.showDevices(a, cur, false);
            if (cur != null && Prefs.castPauseLocal(a)) {
                // the receiving screen plays the sound; stop it here once casting starts
                CastManager.setListener(dev -> { if (dev != null) AudioPlayer.get().stop(); });
            }
        });
        top.addView(castBtn);
        dial.addView(top);

        nameTv = Ui.text(act, "📻 راديو الإنترنت", 22, Ui.ACCENT, true);
        nameTv.setSingleLine(true);
        nameTv.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        nameTv.setMarqueeRepeatLimit(-1);
        nameTv.setSelected(true);
        dial.addView(nameTv, Ui.full(act, 8));
        infoTv = Ui.text(act, "اختر الموجة ثم المحطة من القائمة", 13, Ui.SUB, false);
        infoTv.setSingleLine(true);
        infoTv.setEllipsize(TextUtils.TruncateAt.END);
        dial.addView(infoTv);

        LinearLayout ctr = Ui.row(act);
        Button prev = Ui.button(act, "⏮", Ui.CARD2);
        playBtn = Ui.button(act, "▶ تشغيل", Ui.ACCENT);
        Button next = Ui.button(act, "⏭", Ui.CARD2);
        favBtn = Ui.button(act, "☆", Ui.CARD2);
        sleepBtn = Ui.button(act, "⏾", Ui.CARD2);
        ctr.addView(prev, Ui.weight(act, 1, 3));
        ctr.addView(playBtn, Ui.weight(act, 2, 3));
        ctr.addView(next, Ui.weight(act, 1, 3));
        ctr.addView(favBtn, Ui.weight(act, 1, 3));
        ctr.addView(sleepBtn, Ui.weight(act, 1, 3));
        sleepBtn.setOnClickListener(v -> chooseSleep());
        dial.addView(ctr, Ui.full(act, 8));
        addView(dial);

        prev.setOnClickListener(v -> step(-1));
        next.setOnClickListener(v -> step(1));
        playBtn.setOnClickListener(v -> {
            AudioPlayer pl = AudioPlayer.get();
            if (pl.current() != null && (pl.isPlaying() || statusTv.getText().toString().startsWith("جارِ"))) {
                pl.stop();
            } else if (pl.current() != null) {
                pl.play(a, pl.current());
            } else if (adapter.getCount() > 0) {
                playAt(0);
            }
        });
        favBtn.setOnClickListener(v -> {
            Station s = AudioPlayer.get().current();
            if (s == null) return;
            boolean f = Favorites.toggle(a, "radio", s);
            favBtn.setText(f ? "★" : "☆");
            { adapter.refreshFavs(); adapter.notifyDataSetChanged(); }
        });

        // ---- band chips ----
        LinearLayout chipRow = Ui.row(act);
        for (int i = 0; i < BANDS.length; i++) {
            final String b = BANDS[i];
            Button c = Ui.chipButton(act, i == 3 ? "★ المفضلة" : b);
            c.setOnClickListener(v -> load(b));
            chips[i] = c;
            chipRow.addView(c, Ui.weight(act, 1, 3));
        }
        addView(chipRow, Ui.full(act, 6));

        android.content.SharedPreferences sp = Prefs.p(act);
        fCountry = sp.getString("r_country", Prefs.country(act));
        fCountryName = sp.getString("r_country_n", countryName(fCountry));
        fLang = sp.getString("r_lang", "");
        fLangName = sp.getString("r_lang_n", "كل اللغات");
        fTag = sp.getString("r_tag", "");
        fTagName = sp.getString("r_tag_n", "كل المحتوى");
        fSort = sp.getInt("r_sort", 0);

        android.widget.HorizontalScrollView fs = new android.widget.HorizontalScrollView(act);
        fs.setHorizontalScrollBarEnabled(false);
        filterBar = Ui.row(act);
        countryBtn = filterButton();
        langBtn = filterButton();
        tagBtn = filterButton();
        sortBtn = filterButton();
        Button clear = filterButton();
        clear.setText("✖ مسح");
        countryBtn.setOnClickListener(v -> chooseCountry());
        langBtn.setOnClickListener(v -> chooseLanguage());
        tagBtn.setOnClickListener(v -> chooseTag());
        sortBtn.setOnClickListener(v -> chooseSort());
        clear.setOnClickListener(v -> {
            setCountry(Prefs.country(a), countryName(Prefs.country(a)));
            setLang("", "كل اللغات");
            setTag("", "كل المحتوى");
            fSort = 0;
            saveFilters();
        });
        filterBar.addView(countryBtn, Ui.wrap(act, 2));
        filterBar.addView(langBtn, Ui.wrap(act, 2));
        filterBar.addView(tagBtn, Ui.wrap(act, 2));
        filterBar.addView(sortBtn, Ui.wrap(act, 2));
        filterBar.addView(clear, Ui.wrap(act, 2));
        fs.addView(filterBar);
        addView(fs, Ui.full(act, 2));
        updateFilterLabels();

        EditText search = new EditText(act);
        search.setHint("🔍 ابحث عن محطة…");
        search.setHintTextColor(Ui.SUB);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setBackground(Ui.round(act, Ui.CARD, 12));
        search.setPadding(Ui.dp(act, 14), Ui.dp(act, 9), Ui.dp(act, 14), Ui.dp(act, 9));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { adapter.setFilter(s.toString()); updateCount(); }
            public void afterTextChanged(Editable e) {}
        });
        addView(search, Ui.full(act, 4));

        LinearLayout status = Ui.row(act);
        loading = new ProgressBar(act);
        int sz = Ui.dp(act, 18);
        status.addView(loading, new LayoutParams(sz, sz));
        countTv = Ui.text(act, "", 12.5f, Ui.SUB, false);
        countTv.setPadding(Ui.dp(act, 8), 0, 0, 0);
        status.addView(countTv);
        addView(status, Ui.full(act, 6));

        ListView list = new ListView(act);
        list.setDivider(null);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, pos, id) -> playAt(pos));
        list.setOnItemLongClickListener((parent, view, pos, id) -> {
            Station s = adapter.shown().get(pos);
            CastManager.showOptions(a, s, false, "radio", () -> {
                if (band.equals("★")) load("★"); else { adapter.refreshFavs(); adapter.notifyDataSetChanged(); }
            });
            return true;
        });
        addView(list, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    public void onShown() {
        AudioPlayer.get().addListener(this);
        Station cur = AudioPlayer.get().current();
        if (cur != null) showStation(cur);
        onPlayerStatus(AudioPlayer.get().lastStatus().isEmpty() ? "اختر محطة" : AudioPlayer.get().lastStatus(),
                AudioPlayer.get().isPlaying());
        if (!loadedOnce) load(band);
    }

    public void reload() {
        if (loadedOnce) load(band);
    }

    private void playAt(int pos) {
        if (pos < 0 || pos >= adapter.getCount()) return;
        index = pos;
        Station s = adapter.shown().get(pos);
        AudioPlayer.get().addListener(this);
        AudioPlayer.get().play(a, s);
        showStation(s);
    }

    /** Updates the dial for a station (also used when playing from the library tab). */
    public void showStation(Station s) {
        bandTv.setText(s.band.isEmpty() || s.band.equals("★") ? "📻" : s.band);
        nameTv.setText(s.name);
        infoTv.setText(s.info);
        favBtn.setText(Favorites.has(a, "radio", s.url) ? "★" : "☆");
        adapter.setActive(s.url);
    }

    private void chooseSleep() {
        final int[] mins = {0, 15, 30, 45, 60, 90, 120};
        String[] labels = {"⏹ إلغاء المؤقت", "15 دقيقة", "30 دقيقة", "45 دقيقة", "ساعة", "ساعة ونصف", "ساعتان"};
        int left = AudioPlayer.get().sleepMinutesLeft();
        new android.app.AlertDialog.Builder(a)
                .setTitle(left > 0 ? "⏾ مؤقت النوم (متبقٍ " + left + " د)" : "⏾ إيقاف الراديو تلقائياً بعد")
                .setItems(labels, (d, w) -> {
                    AudioPlayer.get().setSleep(mins[w]);
                    updateSleepBtn();
                    Toast.makeText(a, mins[w] == 0 ? "أُلغي مؤقت النوم" : "سيتوقف الراديو بعد " + labels[w], Toast.LENGTH_SHORT).show();
                }).show();
    }

    private void updateSleepBtn() {
        int left = AudioPlayer.get().sleepMinutesLeft();
        sleepBtn.setText(left > 0 ? "⏾" + left : "⏾");
        sleepBtn.setBackground(Ui.round(a, left > 0 ? Ui.ACCENT2 : Ui.CARD2, 12));
        sleepBtn.setTextColor(left > 0 ? Ui.DARK_TEXT : Ui.TEXT);
    }

    private void step(int dir) {
        int n = adapter.getCount();
        if (n == 0) return;
        int i = index < 0 ? 0 : (index + dir + n) % n;
        playAt(i);
    }

    @Override
    public void onPlayerStatus(String status, boolean playing) {
        updateSleepBtn();
        statusTv.setText(status);
        statusTv.setTextColor(playing ? Ui.GREEN : Ui.SUB);
        playBtn.setText(playing || status.startsWith("جارِ") ? "⏹ إيقاف" : "▶ تشغيل");
    }

    private void updateCount() {
        countTv.setText(adapter.getCount() + " محطة • اضغط مطولاً للخيارات");
    }

    private String query(String b) {
        StringBuilder q = new StringBuilder("/json/stations/search?hidebroken=true&limit=500");
        q.append("&order=").append(SORTS[fSort][0]).append("&reverse=").append(SORTS[fSort][1]);
        List<String> tags = new ArrayList<>();
        if (b.equals("AM")) tags.add("am");
        if (b.equals("SW")) tags.add("shortwave");
        if (!fTag.isEmpty()) tags.add(fTag);
        if (!tags.isEmpty()) q.append("&tagList=").append(enc(TextUtils.join(",", tags)));
        if (!fCountry.isEmpty() && !anyCountry) q.append("&countrycode=").append(fCountry);
        if (!fLang.isEmpty()) q.append("&language=").append(enc(fLang));
        return q.toString();
    }

    static String enc(String s) {
        try { return java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20"); } catch (Exception e) { return s; }
    }

    // ---------------- filter UI ----------------

    private Button filterButton() {
        Button b = Ui.chipButton(a, "");
        b.setTextSize(12.5f);
        b.setMinimumHeight(Ui.dp(a, 34));
        b.setPadding(Ui.dp(a, 12), 0, Ui.dp(a, 12), 0);
        return b;
    }

    private void updateFilterLabels() {
        countryBtn.setText("🌍 " + (fCountry.isEmpty() ? "كل الدول" : fCountryName) + " ▾");
        langBtn.setText("🗣 " + fLangName + " ▾");
        tagBtn.setText("🎵 " + fTagName + " ▾");
        sortBtn.setText(SORTS[fSort][2] + " ▾");
        Ui.chip(a, countryBtn, !fCountry.isEmpty());
        Ui.chip(a, langBtn, !fLang.isEmpty());
        Ui.chip(a, tagBtn, !fTag.isEmpty());
        Ui.chip(a, sortBtn, fSort != 0);
        boolean fav = band.equals("★");
        for (int i = 0; i < filterBar.getChildCount(); i++) filterBar.getChildAt(i).setAlpha(fav ? 0.4f : 1f);
    }

    private void saveFilters() {
        Prefs.edit(a).putString("r_country", fCountry).putString("r_country_n", fCountryName)
                .putString("r_lang", fLang).putString("r_lang_n", fLangName)
                .putString("r_tag", fTag).putString("r_tag_n", fTagName)
                .putInt("r_sort", fSort).apply();
        updateFilterLabels();
        if (band.equals("★")) load("FM"); else load(band);
    }

    private void setCountry(String code, String name) { fCountry = code; fCountryName = name; }
    private void setLang(String code, String name) { fLang = code; fLangName = name; }
    private void setTag(String code, String name) { fTag = code; fTagName = name; }

    static String countryName(String code) {
        for (String[] c : SettingsPanel.COUNTRIES) if (c[0].equalsIgnoreCase(code)) return c[1];
        return TvPanel.countryAr(code);
    }

    /** Shows a quick list; the last entry loads the full list from the radio directory. */
    private void pick(String title, final String[] labels, final Picked onPick) {
        new android.app.AlertDialog.Builder(a).setTitle(title)
                .setItems(labels, (d, w) -> onPick.on(w)).show();
    }

    private void chooseCountry() {
        final String[][] cs = SettingsPanel.COUNTRIES;
        String[] labels = new String[cs.length + 2];
        labels[0] = "🌐 كل الدول";
        for (int i = 0; i < cs.length; i++) labels[i + 1] = cs[i][1];
        labels[cs.length + 1] = "📋 كل الدول في الدليل…";
        pick("الدولة", labels, w -> {
            if (w == 0) { setCountry("", "كل الدول"); saveFilters(); }
            else if (w <= cs.length) { setCountry(cs[w - 1][0], cs[w - 1][1]); saveFilters(); }
            else loadDirectory("/json/countries?order=stationcount&reverse=true&hidebroken=true", "iso_3166_1", "الدولة",
                    (code, name) -> { setCountry(code, name); saveFilters(); });
        });
    }

    private void chooseLanguage() {
        String[] labels = new String[LANGS.length + 1];
        for (int i = 0; i < LANGS.length; i++) labels[i] = LANGS[i][1];
        labels[LANGS.length] = "📋 كل اللغات في الدليل…";
        pick("اللغة", labels, w -> {
            if (w < LANGS.length) { setLang(LANGS[w][0], LANGS[w][1]); saveFilters(); }
            else loadDirectory("/json/languages?order=stationcount&reverse=true&hidebroken=true&limit=150", "name", "اللغة",
                    (code, name) -> { setLang(code, name); saveFilters(); });
        });
    }

    private void chooseTag() {
        String[] labels = new String[TAGS.length + 1];
        for (int i = 0; i < TAGS.length; i++) labels[i] = TAGS[i][1];
        labels[TAGS.length] = "📋 كل التصنيفات في الدليل…";
        pick("المحتوى", labels, w -> {
            if (w < TAGS.length) { setTag(TAGS[w][0], TAGS[w][1]); saveFilters(); }
            else loadDirectory("/json/tags?order=stationcount&reverse=true&hidebroken=true&limit=200", "name", "المحتوى",
                    (code, name) -> { setTag(code, name); saveFilters(); });
        });
    }

    private void chooseSort() {
        String[] labels = new String[SORTS.length];
        for (int i = 0; i < SORTS.length; i++) labels[i] = SORTS[i][2];
        pick("الترتيب", labels, w -> { fSort = w; saveFilters(); });
    }

    interface Chosen { void on(String code, String name); }

    /** Loads countries / languages / tags with their station counts from radio-browser. */
    private void loadDirectory(String path, final String codeField, final String title, final Chosen chosen) {
        final android.app.ProgressDialog pd = android.app.ProgressDialog.show(a, title, "جارِ التحميل…", true, true);
        String[] urls = new String[SERVERS.length];
        for (int i = 0; i < SERVERS.length; i++) urls[i] = SERVERS[i] + path;
        Net.get(urls, new Net.Callback() {
            @Override public void ok(String body) {
                try { pd.dismiss(); } catch (Exception ignored) {}
                final List<String> codes = new ArrayList<>();
                final List<String> names = new ArrayList<>();
                List<String> labels = new ArrayList<>();
                try {
                    JSONArray arr = new JSONArray(body);
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        String code = o.optString(codeField).trim();
                        String name = o.optString("name").trim();
                        int n = o.optInt("stationcount");
                        if (code.isEmpty() || n < 3) continue;
                        String shown = codeField.equals("iso_3166_1") ? countryLabel(code, name) : name;
                        codes.add(code);
                        names.add(shown);
                        labels.add(shown + "  (" + n + ")");
                    }
                } catch (Exception ignored) {}
                if (codes.isEmpty()) {
                    Toast.makeText(a, "تعذّر تحميل القائمة", Toast.LENGTH_SHORT).show();
                    return;
                }
                pick(title, labels.toArray(new String[0]), w -> chosen.on(codes.get(w), names.get(w)));
            }
            @Override public void err(String message) {
                try { pd.dismiss(); } catch (Exception ignored) {}
                Toast.makeText(a, "تعذّر التحميل — تأكد من الإنترنت", Toast.LENGTH_SHORT).show();
            }
        });
    }

    static String countryLabel(String code, String english) {
        String ar = countryName(code);
        return ar.equals(code) ? english : ar;
    }

    private void load(final String b) {
        anyCountry = false;
        loadInternal(b);
    }

    private void loadInternal(final String b) {
        loadedOnce = true;
        band = b;
        index = -1;
        for (int i = 0; i < BANDS.length; i++) Ui.chip(a, chips[i], BANDS[i].equals(b));
        if (filterBar != null) updateFilterLabels();
        final int my = ++seq;
        if (b.equals("★")) {
            loading.setVisibility(View.GONE);
            adapter.setData(Favorites.load(a, "radio"));
            countTv.setText(adapter.getCount() == 0 ? "لا توجد محطات مفضلة — اضغط مطولاً على أي محطة" : adapter.getCount() + " محطة مفضلة");
            return;
        }
        loading.setVisibility(View.VISIBLE);
        countTv.setText("جارِ تحميل محطات " + b + "…");
        adapter.setData(new ArrayList<Station>());
        String q = query(b);
        String[] urls = new String[SERVERS.length];
        for (int i = 0; i < SERVERS.length; i++) urls[i] = SERVERS[i] + q;
        Net.get(urls, new Net.Callback() {
            @Override public void ok(String body) {
                if (my != seq) return;
                loading.setVisibility(View.GONE);
                List<Station> res = parse(body, b);
                if (res.isEmpty() && !b.equals("FM") && !fCountry.isEmpty() && !anyCountry) {
                    anyCountry = true;
                    loadInternal(b);
                    return;
                }
                adapter.setData(res);
                if (anyCountry && !res.isEmpty()) {
                    countTv.setText(res.size() + " محطة " + b + " من كل الدول (لا توجد محطات " + b + " لـ " + fCountryName + ")");
                } else if (adapter.totalCount() == 0) {
                    countTv.setText("لا توجد محطات بهذه الفلاتر — جرّب «✖ مسح» أو اختر فلتراً آخر");
                } else updateCount();
            }
            @Override public void err(String message) {
                if (my != seq) return;
                loading.setVisibility(View.GONE);
                countTv.setText("تعذّر التحميل — تأكد من الإنترنت");
            }
        });
    }

    static List<Station> parse(String body, String band) {
        List<Station> out = new ArrayList<>();
        try {
            JSONArray arr = new JSONArray(body);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.getJSONObject(i);
                Station s = new Station();
                s.name = o.optString("name").trim();
                s.url = o.optString("url_resolved");
                if (s.url.isEmpty()) s.url = o.optString("url");
                if (s.url.isEmpty() || s.name.isEmpty()) continue;
                StringBuilder sb = new StringBuilder();
                String country = o.optString("country");
                if (!country.isEmpty()) sb.append(country);
                String lang = o.optString("language");
                if (!lang.isEmpty()) {
                    int comma = lang.indexOf(',');
                    sb.append(sb.length() > 0 ? " • " : "").append(comma > 0 ? lang.substring(0, comma) : lang);
                }
                String codec = o.optString("codec");
                int br = o.optInt("bitrate");
                if (!codec.isEmpty()) sb.append(sb.length() > 0 ? " • " : "").append(codec);
                if (br > 0) sb.append(" ").append(br).append("kbps");
                s.info = sb.toString();
                s.band = band;
                s.logo = o.optString("favicon");
                out.add(s);
            }
        } catch (Exception ignored) {}
        return out;
    }
}
