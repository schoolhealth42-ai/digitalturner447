package com.dtvradio.tuner;

import android.content.Context;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.List;

/** Favorites stored as JSON in SharedPreferences. key = "tv", "radio", "hist_tv", "hist_radio". */
public final class Favorites {
    private Favorites() {}

    public static List<Station> load(Context c, String key) {
        List<Station> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(Prefs.p(c).getString("fav_" + key, "[]"));
            for (int i = 0; i < a.length(); i++) out.add(Station.fromJson(a.getJSONObject(i)));
        } catch (Exception ignored) {}
        return out;
    }

    public static void save(Context c, String key, List<Station> list) {
        JSONArray a = new JSONArray();
        try {
            for (Station s : list) a.put(s.toJson());
        } catch (Exception ignored) {}
        Prefs.edit(c).putString("fav_" + key, a.toString()).apply();
    }

    public static boolean has(Context c, String key, String url) {
        for (Station s : load(c, key)) if (s.url.equals(url)) return true;
        return false;
    }

    /** @return true if the station is now a favorite. */
    public static boolean toggle(Context c, String key, Station st) {
        List<Station> list = load(c, key);
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).url.equals(st.url)) {
                list.remove(i);
                save(c, key, list);
                return false;
            }
        }
        list.add(st);
        save(c, key, list);
        return true;
    }
}
