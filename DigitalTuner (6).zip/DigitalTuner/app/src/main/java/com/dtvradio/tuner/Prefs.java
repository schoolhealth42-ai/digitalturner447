package com.dtvradio.tuner;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private Prefs() {}

    static SharedPreferences p(Context c) {
        return c.getSharedPreferences("tuner_prefs", Context.MODE_PRIVATE);
    }

    public static SharedPreferences.Editor edit(Context c) { return p(c).edit(); }

    // ---- general / appearance ----
    public static String country(Context c) { return p(c).getString("country", "SA"); }
    public static int lastTab(Context c) { return p(c).getInt("tab", 0); }
    /** -1 = reopen the last tab, otherwise a tab index. */
    public static int startTab(Context c) { return p(c).getInt("starttab", -1); }
    public static int accent(Context c) { return p(c).getInt("accent", 0); }
    public static boolean amoled(Context c) { return p(c).getBoolean("amoled", false); }
    /** 0 small, 1 normal, 2 large. */
    public static int fontSize(Context c) { return p(c).getInt("fontsize", 1); }

    // ---- TV ----
    public static String customM3u(Context c) { return p(c).getString("m3u", ""); }
    /** 0 auto, 1 low (weak internet), 2 medium, 3 high, 4 audio only. */
    public static int quality(Context c) { return p(c).getInt("quality", 0); }
    public static boolean sortLight(Context c) { return p(c).getBoolean("sortlight", false); }
    public static boolean extraSources(Context c) { return p(c).getBoolean("extrasrc", true); }
    public static boolean hideGeo(Context c) { return p(c).getBoolean("hidegeo", false); }
    public static boolean hideNot247(Context c) { return p(c).getBoolean("hide247", false); }
    public static boolean autoPip(Context c) { return p(c).getBoolean("autopip", true); }
    public static boolean showLogos(Context c) { return p(c).getBoolean("logos", true) && !dataSaver(c); }

    // ---- radio ----
    public static boolean bgPlayback(Context c) { return p(c).getBoolean("bgplay", true); }
    public static boolean autoResume(Context c) { return p(c).getBoolean("autoresume", false); }
    public static int sleepDefault(Context c) { return p(c).getInt("sleepdef", 30); }

    // ---- translation to Arabic ----
    public static boolean trCaptions(Context c) { return p(c).getBoolean("trcc", false); }
    public static boolean trNames(Context c) { return p(c).getBoolean("trnames", false); }
    public static boolean trShowOriginal(Context c) { return p(c).getBoolean("trorig", true); }
    public static boolean trWifiOnly(Context c) { return p(c).getBoolean("trwifi", false); }
    /** "" = detect automatically, otherwise an ML Kit language code (en, fr, tr …). */
    public static String trSource(Context c) { return p(c).getString("trsrc", ""); }

    // ---- casting / receiver mode ----
    public static boolean receiverMode(Context c) { return p(c).getBoolean("rcv", false); }
    public static boolean castPauseLocal(Context c) { return p(c).getBoolean("castpause", true); }

    // ---- data ----
    public static boolean dataSaver(Context c) { return p(c).getBoolean("datasaver", false); }
    public static int cacheHours(Context c) { return p(c).getInt("cachehours", 6); }

    /** Effective TV quality: data saver turns "auto" into "low". */
    public static int effectiveQuality(Context c) {
        int q = quality(c);
        return (dataSaver(c) && (q == 0 || q == 3)) ? 1 : q;
    }
}
