package com.dtvradio.tuner;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Expanded, grouped settings. Every change is applied immediately. */
public class SettingsPanel extends ScrollView {
    /** Quick country list used by the radio filters. */
    static final String[][] COUNTRIES = {
            {"SA", "السعودية"}, {"AE", "الإمارات"}, {"KW", "الكويت"}, {"QA", "قطر"}, {"BH", "البحرين"},
            {"OM", "عُمان"}, {"YE", "اليمن"}, {"IQ", "العراق"}, {"JO", "الأردن"}, {"SY", "سوريا"},
            {"LB", "لبنان"}, {"PS", "فلسطين"}, {"EG", "مصر"}, {"SD", "السودان"}, {"LY", "ليبيا"},
            {"TN", "تونس"}, {"DZ", "الجزائر"}, {"MA", "المغرب"}, {"MR", "موريتانيا"}, {"TR", "تركيا"},
            {"GB", "بريطانيا"}, {"US", "أمريكا"}, {"FR", "فرنسا"}, {"DE", "ألمانيا"}
    };

    interface Pick { void on(int which); }

    private final MainActivity a;
    private final LinearLayout root;
    private TextView cacheValue;
    private TextView rcvStatus, rcvNameVal;

    public SettingsPanel(MainActivity act) {
        super(act);
        a = act;
        root = new LinearLayout(act);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(act, 12);
        root.setPadding(p, p / 2, p, p * 3);
        addView(root);
        build();
    }

    public void onShown() {
        if (cacheValue != null) cacheValue.setText(sizeLabel(Net.cacheSize()));
    }

    private SharedPreferences sp() { return Prefs.p(a); }

    // ======================================================================
    private void build() {
        // ---------- appearance ----------
        LinearLayout ap = section("🎨 المظهر");
        colorRow(ap);
        switchRow(ap, "الوضع الأسود الكامل (AMOLED)", "أسود حقيقي يوفّر البطارية في شاشات OLED",
                "amoled", false, "theme");
        choiceRow(ap, "حجم الخط", new String[]{"صغير", "عادي", "كبير"}, Prefs.fontSize(a), w -> {
            sp().edit().putInt("fontsize", w).apply();
            a.onSettingsChanged("theme");
        });
        choiceRow(ap, "التبويب عند فتح التطبيق",
                new String[]{"آخر تبويب استخدمته", "📺 تلفاز", "📻 راديو", "📚 مكتبتي"},
                Prefs.startTab(a) + 1, w -> sp().edit().putInt("starttab", w - 1).apply());

        // ---------- TV ----------
        LinearLayout tvc = section("📺 التلفاز");
        countryRow(tvc);
        choiceRow(tvc, "جودة البث الافتراضية", PlayerActivity.QUALITY, Prefs.quality(a),
                w -> sp().edit().putInt("quality", w).apply());
        switchRow(tvc, "صورة داخل صورة تلقائياً", "يستمر عرض القناة في نافذة صغيرة عند الخروج من التطبيق",
                "autopip", true, null);
        switchRow(tvc, "عرض شعارات القنوات والمحطات", "إيقافها يوفّر البيانات ويسرّع القوائم",
                "logos", true, "tv");
        switchRow(tvc, "القنوات الأخف أولاً", "ترتيب القنوات من الأقل جودة إلى الأعلى (للنت الضعيف)",
                "sortlight", false, "tv");
        switchRow(tvc, "إخفاء القنوات المحجوبة جغرافياً", "القنوات المعلَّمة [Geo-blocked] لا تعمل غالباً خارج بلدها",
                "hidegeo", false, "tv");
        switchRow(tvc, "إخفاء القنوات غير المستمرة", "القنوات المعلَّمة [Not 24/7] لا تبث طوال اليوم",
                "hide247", false, "tv");
        switchRow(tvc, "مصادر إضافية (Free-TV)", "دمج قنوات من مصدر ثانٍ لزيادة عدد القنوات",
                "extrasrc", true, "tv");

        // ---------- radio ----------
        LinearLayout rc = section("📻 الراديو");
        switchRow(rc, "التشغيل في الخلفية", "يستمر الراديو مع إطفاء الشاشة، مع إشعار فيه زر إيقاف",
                "bgplay", true, null);
        switchRow(rc, "استئناف آخر محطة عند فتح التطبيق", "يبدأ تشغيل آخر محطة استمعت إليها تلقائياً",
                "autoresume", false, null);
        final int[] sleeps = {15, 30, 45, 60, 90, 120};
        int sIdx = 1;
        for (int i = 0; i < sleeps.length; i++) if (sleeps[i] == Prefs.sleepDefault(a)) sIdx = i;
        choiceRow(rc, "مدة مؤقت النوم المقترحة",
                new String[]{"15 دقيقة", "30 دقيقة", "45 دقيقة", "ساعة", "ساعة ونصف", "ساعتان"}, sIdx,
                w -> sp().edit().putInt("sleepdef", sleeps[w]).apply());

        // ---------- casting & receiver mode ----------
        LinearLayout cs = section("📡 العرض على التلفاز والريسيفر والجوالات");
        cs.addView(Ui.text(a,
                "أرسل أي قناة أو محطة إلى: تلفاز ذكي (DLNA)، أو Chromecast / Google TV، أو ريسيفر أندرويد مثل غزال، "
                        + "أو جوال آخر — من زر «📡 عرض» في المشغّل والراديو، أو بالضغط المطوّل على أي قناة.",
                12, Ui.SUB, false), Ui.full(a, 8));
        switchRow(cs, "وضع الاستقبال: اجعل هذا الجهاز شاشة عرض",
                "فعّله على الريسيفر أو التلفاز الذكي (أندرويد) أو الجوال الآخر، ليستقبل القنوات من جوالك عبر نفس الواي فاي",
                "rcv", false, "receiver");
        rcvStatus = Ui.text(a, "", 12.5f, Ui.GREEN, false);
        rcvStatus.setPadding(0, 0, 0, Ui.dp(a, 8));
        cs.addView(rcvStatus);
        updateRcvStatus(DlnaRenderer.isRunning(), DlnaRenderer.address());
        DlnaRenderer.setStatusListener(this::updateRcvStatus);
        String curName = sp().getString("rcv_name", "");
        rcvNameVal = actionRow(cs, "اسم هذا الجهاز عند العرض", "يظهر بهذا الاسم في قائمة الشاشات على الجوال الآخر",
                curName.isEmpty() ? "تلقائي ✎" : curName + " ✎", this::editReceiverName);
        switchRow(cs, "إيقاف التشغيل على الجوال أثناء العرض", "حتى لا يتكرر الصوت بين الجوال والتلفاز",
                "castpause", true, null);
        actionRow(cs, "مشاركة شاشة الجوال كاملة", "Screen Mirroring / Smart View — يعمل مع معظم الشاشات الذكية", "🪞",
                () -> CastManager.openMirroring(a));

        // ---------- translation ----------
        LinearLayout trc = section("🌐 الترجمة إلى العربية (اختياري)");
        trc.addView(Ui.text(a,
                "تتم الترجمة على جهازك بعد تنزيل حزمة اللغة مرة واحدة (حوالي 30 ميجابايت لكل لغة)، ثم تعمل بدون إنترنت.",
                12, Ui.SUB, false), Ui.full(a, 8));
        switchRow(trc, "ترجمة نصوص القنوات أثناء المشاهدة",
                "تُترجم النصوص المرافقة (CC) للقنوات الأجنبية إلى العربية. يمكن تشغيلها أيضاً من زر 🌐 داخل المشغّل",
                "trcc", false, null);
        switchRow(trc, "عرض النص الأصلي تحت الترجمة", "مفيد لتعلّم اللغة أو للتحقق من الترجمة",
                "trorig", true, null);
        switchRow(trc, "ترجمة أسماء القنوات إلى العربية", "يظهر الاسم العربي أولاً والاسم الأصلي تحته",
                "trnames", false, "tv");
        final String[] srcLabels = new String[Tr.SOURCES.length];
        int srcIdx = 0;
        for (int i = 0; i < Tr.SOURCES.length; i++) {
            srcLabels[i] = Tr.SOURCES[i][1];
            if (Tr.SOURCES[i][0].equals(Prefs.trSource(a))) srcIdx = i;
        }
        choiceRow(trc, "لغة القنوات المترجَمة", srcLabels, srcIdx,
                w -> sp().edit().putString("trsrc", Tr.SOURCES[w][0]).apply());
        switchRow(trc, "تنزيل حزم الترجمة عبر الواي فاي فقط", "لتوفير باقة الجوال",
                "trwifi", false, null);
        actionRow(trc, "تنزيل حزمة الترجمة الآن", "جهّزها مسبقاً لتعمل الترجمة فوراً", "⬇", () -> {
            String src = Prefs.trSource(a).isEmpty() ? "en" : Prefs.trSource(a);
            toast("جارِ تنزيل حزمة الترجمة…");
            Tr.prepare(a, src, ok -> toast(ok == null ? "تعذّر التنزيل — تحقق من الاتصال" : "حزمة الترجمة جاهزة ✓"));
        });
        actionRow(trc, "حذف حزم الترجمة", "لتحرير مساحة التخزين", "🗑", () ->
                confirm("حذف كل حزم الترجمة المنزّلة؟", () -> Tr.deleteModels(r ->
                        toast(r == null ? "تعذّر الحذف" : "تم حذف حزم الترجمة"))));

        // ---------- data ----------
        LinearLayout dc = section("📶 البيانات والتخزين");
        switchRow(dc, "موفّر البيانات", "جودة منخفضة تلقائياً وبدون شعارات — مثالي للنت الضعيف أو الباقات المحدودة",
                "datasaver", false, "tv");
        final int[] hours = {0, 1, 6, 24, 72};
        int hIdx = 2;
        for (int i = 0; i < hours.length; i++) if (hours[i] == Prefs.cacheHours(a)) hIdx = i;
        choiceRow(dc, "حفظ قوائم القنوات على الجهاز",
                new String[]{"بدون حفظ", "ساعة", "6 ساعات", "يوم", "3 أيام"}, hIdx, w -> {
                    sp().edit().putInt("cachehours", hours[w]).apply();
                    a.onSettingsChanged("net");
                });
        cacheValue = actionRow(dc, "مسح الذاكرة المؤقتة", "القوائم المحفوظة تفتح فوراً وتعمل عند انقطاع النت",
                sizeLabel(Net.cacheSize()), () -> {
                    Net.clearCache();
                    cacheValue.setText(sizeLabel(Net.cacheSize()));
                    toast("تم مسح الذاكرة المؤقتة");
                });

        // ---------- custom lists ----------
        LinearLayout mc = section("📂 قوائمي الخاصة (M3U)");
        mc.addView(Ui.text(a, "ضع رابطاً أو أكثر (كل رابط في سطر). تظهر قنواتها في تبويب «تلفاز ← قائمتي».",
                12.5f, Ui.SUB, false));
        final EditText m3u = new EditText(a);
        m3u.setText(Prefs.customM3u(a));
        m3u.setHint("https://example.com/playlist.m3u");
        m3u.setHintTextColor(Ui.SUB);
        m3u.setTextColor(Ui.TEXT);
        m3u.setMinLines(3);
        m3u.setGravity(Gravity.TOP | Gravity.START);
        m3u.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_VARIATION_URI);
        m3u.setTextDirection(TEXT_DIRECTION_LTR);
        m3u.setBackground(Ui.round(a, Ui.CARD2, 10));
        m3u.setPadding(Ui.dp(a, 12), Ui.dp(a, 8), Ui.dp(a, 12), Ui.dp(a, 8));
        mc.addView(m3u, Ui.full(a, 8));
        Button saveM3u = Ui.button(a, "💾 حفظ القوائم", Ui.ACCENT);
        saveM3u.setOnClickListener(v -> {
            sp().edit().putString("m3u", m3u.getText().toString().trim()).apply();
            a.onSettingsChanged("tv");
            toast("تم حفظ القوائم ✓");
        });
        mc.addView(saveM3u, Ui.full(a, 8));

        // ---------- favorites & history ----------
        LinearLayout fc = section("⭐ المفضلة والسجل");
        actionRow(fc, "تصدير المفضلة", "مشاركة نسخة احتياطية من قنواتك ومحطاتك المفضلة", "↗", this::exportFavorites);
        actionRow(fc, "استيراد المفضلة", "انسخ نص النسخة الاحتياطية ثم اضغط هنا", "↙", this::importFavorites);
        actionRow(fc, "مسح سجل المشاهدة والاستماع", "", "🗑", () -> confirm("مسح السجل بالكامل؟", () -> {
            History.clear(a);
            toast("تم مسح السجل");
        }));

        // ---------- about ----------
        LinearLayout ab = section("ℹ️ عن التطبيق");
        String ver = "3.0";
        try { ver = a.getPackageManager().getPackageInfo(a.getPackageName(), 0).versionName; } catch (Exception ignored) {}
        ab.addView(Ui.text(a, "الموالف الرقمي — الإصدار " + ver, 15, Ui.TEXT, true));
        ab.addView(Ui.text(a,
                "• التلفاز: قوائم iptv-org العامة لكل دول العالم + Free-TV.\n"
                        + "• الراديو: دليل radio-browser.info المفتوح.\n"
                        + "• الترجمة: Google ML Kit على الجهاز.\n"
                        + "• القنوات من مصادر عامة خارجية، وقد يتوقف بعضها أو يُحجب حسب المنطقة.",
                12.5f, Ui.SUB, false), Ui.full(a, 6));
        actionRow(ab, "استعادة الإعدادات الافتراضية", "لا يمسّ المفضلة والسجل", "↺",
                () -> confirm("إرجاع كل الإعدادات إلى الوضع الافتراضي؟", this::resetSettings));
    }

    // ======================================================================
    // building blocks

    private LinearLayout section(String title) {
        TextView h = Ui.text(a, title, 14, Ui.ACCENT, true);
        h.setPadding(Ui.dp(a, 6), Ui.dp(a, 18), Ui.dp(a, 6), Ui.dp(a, 6));
        root.addView(h);
        LinearLayout card = Ui.card(a);
        card.setPadding(Ui.dp(a, 14), Ui.dp(a, 4), Ui.dp(a, 14), Ui.dp(a, 4));
        root.addView(card, Ui.full(a, 0));
        return card;
    }

    private LinearLayout rowBase(LinearLayout card, String title, String sub) {
        if (card.getChildCount() > 0) {
            View div = new View(a);
            div.setBackgroundColor(0x22FFFFFF);
            card.addView(div, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 1));
        }
        LinearLayout row = Ui.row(a);
        row.setPadding(0, Ui.dp(a, 12), 0, Ui.dp(a, 12));
        LinearLayout col = new LinearLayout(a);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(Ui.text(a, title, 15, Ui.TEXT, false));
        if (sub != null && !sub.isEmpty()) {
            TextView s = Ui.text(a, sub, 12, Ui.SUB, false);
            s.setPadding(0, Ui.dp(a, 2), 0, 0);
            col.addView(s);
        }
        row.addView(col, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        card.addView(row);
        return row;
    }

    /** A switch stored in prefs; {@code reload} is passed to MainActivity.onSettingsChanged. */
    private void switchRow(LinearLayout card, String title, String sub, final String key, boolean def, final String reload) {
        LinearLayout row = rowBase(card, title, sub);
        final Switch sw = new Switch(a);
        sw.setChecked(sp().getBoolean(key, def));
        sw.setOnCheckedChangeListener((b, on) -> {
            sp().edit().putBoolean(key, on).apply();
            if (reload != null) a.onSettingsChanged(reload);
        });
        row.addView(sw, Ui.wrap(a, 4));
        row.setOnClickListener(v -> sw.toggle());
    }

    private void choiceRow(LinearLayout card, final String title, final String[] items, int current, final Pick pick) {
        LinearLayout row = rowBase(card, title, null);
        final int cur = (current >= 0 && current < items.length) ? current : 0;
        final TextView val = Ui.text(a, items[cur] + "  ▾", 13.5f, Ui.ACCENT, true);
        row.addView(val, Ui.wrap(a, 4));
        final int[] selected = {cur};
        row.setOnClickListener(v -> new AlertDialog.Builder(a)
                .setTitle(title)
                .setSingleChoiceItems(items, selected[0], (d, w) -> {
                    selected[0] = w;
                    val.setText(items[w] + "  ▾");
                    d.dismiss();
                    pick.on(w);
                }).show());
    }

    private TextView actionRow(LinearLayout card, String title, String sub, String value, final Runnable r) {
        LinearLayout row = rowBase(card, title, sub);
        TextView val = Ui.text(a, value, 14, Ui.ACCENT, true);
        row.addView(val, Ui.wrap(a, 4));
        row.setOnClickListener(v -> r.run());
        return val;
    }

    private void colorRow(LinearLayout card) {
        rowBase(card, "لون التطبيق", null);
        LinearLayout colors = Ui.row(a);
        colors.setPadding(0, 0, 0, Ui.dp(a, 12));
        int cur = Prefs.accent(a);
        for (int i = 0; i < Ui.ACCENTS.length; i++) {
            final int idx = i;
            TextView dot = new TextView(a);
            dot.setGravity(Gravity.CENTER);
            dot.setText(i == cur ? "✓" : "");
            dot.setTextColor(Ui.DARK_TEXT);
            dot.setTextSize(16);
            dot.setBackground(Ui.round(a, Ui.ACCENTS[i], 18));
            dot.setContentDescription(Ui.ACCENT_NAMES[i]);
            int s = Ui.dp(a, 36);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(s, s);
            lp.setMarginEnd(Ui.dp(a, 10));
            dot.setOnClickListener(v -> {
                sp().edit().putInt("accent", idx).apply();
                a.onSettingsChanged("theme");
            });
            colors.addView(dot, lp);
        }
        card.addView(colors);
    }

    /** Home country: every country in the world, sorted in Arabic, with search. */
    private void countryRow(LinearLayout card) {
        LinearLayout row = rowBase(card, "دولتي", "تُستخدم لزر «🏠 بلدي» في التلفاز ولمحطات FM في الراديو");
        final TextView val = Ui.text(a, TvPanel.flag(Prefs.country(a)) + " " + TvPanel.countryAr(Prefs.country(a)) + "  ▾",
                13.5f, Ui.ACCENT, true);
        row.addView(val, Ui.wrap(a, 4));
        row.setOnClickListener(v -> {
            final List<String[]> all = new ArrayList<>();
            for (String cc : Locale.getISOCountries()) all.add(new String[]{cc, TvPanel.countryAr(cc)});
            final Collator col = Collator.getInstance(new Locale("ar"));
            Collections.sort(all, (x, y) -> col.compare(x[1], y[1]));
            String[] labels = new String[all.size()];
            for (int i = 0; i < all.size(); i++) labels[i] = TvPanel.flag(all.get(i)[0]) + "  " + all.get(i)[1];
            new AlertDialog.Builder(a).setTitle("دولتي").setItems(labels, (d, w) -> {
                String code = all.get(w)[0];
                sp().edit().putString("country", code).apply();
                val.setText(TvPanel.flag(code) + " " + TvPanel.countryAr(code) + "  ▾");
                a.onSettingsChanged("all");
            }).show();
        });
    }

    // ======================================================================
    // actions

    private void updateRcvStatus(boolean running, String address) {
        if (rcvStatus == null) return;
        if (!Prefs.receiverMode(a)) {
            rcvStatus.setVisibility(View.GONE);
            return;
        }
        rcvStatus.setVisibility(View.VISIBLE);
        if (running) {
            rcvStatus.setTextColor(Ui.GREEN);
            rcvStatus.setText("✅ جاهز للاستقبال باسم «" + DlnaRenderer.deviceName() + "» على " + address
                    + "\nأبقِ التطبيق مفتوحاً على هذا الجهاز.");
        } else {
            rcvStatus.setTextColor(Ui.ACCENT2);
            rcvStatus.setText("⏳ لم يبدأ بعد — تأكد أن الجهاز متصل بشبكة واي فاي أو كابل إنترنت");
        }
    }

    private void editReceiverName() {
        final EditText e = new EditText(a);
        e.setText(sp().getString("rcv_name", ""));
        e.setHint(DlnaRenderer.defaultName());
        e.setSingleLine(true);
        new AlertDialog.Builder(a).setTitle("اسم هذا الجهاز").setView(e)
                .setPositiveButton("حفظ", (d, w) -> {
                    String n = e.getText().toString().trim();
                    sp().edit().putString("rcv_name", n).apply();
                    rcvNameVal.setText(n.isEmpty() ? "تلقائي ✎" : n + " ✎");
                    if (Prefs.receiverMode(a)) {
                        DlnaRenderer.stop();
                        DlnaRenderer.start(a);
                    }
                })
                .setNegativeButton("إلغاء", null).show();
    }

    private void exportFavorites() {
        try {
            JSONObject o = new JSONObject();
            JSONArray tv = new JSONArray(), radio = new JSONArray();
            for (Station s : Favorites.load(a, "tv")) tv.put(s.toJson());
            for (Station s : Favorites.load(a, "radio")) radio.put(s.toJson());
            o.put("app", "DigitalTuner");
            o.put("tv", tv);
            o.put("radio", radio);
            Intent i = new Intent(Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(Intent.EXTRA_SUBJECT, "نسخة احتياطية — مفضلة الموالف الرقمي");
            i.putExtra(Intent.EXTRA_TEXT, o.toString());
            a.startActivity(Intent.createChooser(i, "تصدير المفضلة"));
        } catch (Exception e) {
            toast("تعذّر التصدير");
        }
    }

    private void importFavorites() {
        try {
            ClipboardManager cm = (ClipboardManager) a.getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData cd = cm == null ? null : cm.getPrimaryClip();
            if (cd == null || cd.getItemCount() == 0) {
                toast("انسخ نص النسخة الاحتياطية أولاً");
                return;
            }
            JSONObject o = new JSONObject(String.valueOf(cd.getItemAt(0).coerceToText(a)));
            int added = merge("tv", o.optJSONArray("tv")) + merge("radio", o.optJSONArray("radio"));
            toast("تم استيراد " + added + " عنصر ✓");
            a.onSettingsChanged("all");
        } catch (Exception e) {
            toast("النص المنسوخ ليس نسخة احتياطية صالحة");
        }
    }

    private int merge(String key, JSONArray arr) throws Exception {
        if (arr == null) return 0;
        List<Station> list = Favorites.load(a, key);
        int n = 0;
        for (int i = 0; i < arr.length(); i++) {
            Station s = Station.fromJson(arr.getJSONObject(i));
            boolean exists = false;
            for (Station x : list) if (x.url.equals(s.url)) exists = true;
            if (!exists && !s.url.isEmpty()) {
                list.add(s);
                n++;
            }
        }
        Favorites.save(a, key, list);
        return n;
    }

    private void resetSettings() {
        SharedPreferences.Editor e = sp().edit();
        for (String k : sp().getAll().keySet()) {
            if (!k.startsWith("fav_")) e.remove(k);
        }
        e.apply();
        toast("تمت استعادة الإعدادات الافتراضية");
        a.onSettingsChanged("theme");
    }

    private void confirm(String msg, final Runnable r) {
        new AlertDialog.Builder(a).setMessage(msg)
                .setPositiveButton("نعم", (d, w) -> r.run())
                .setNegativeButton("إلغاء", null).show();
    }

    private void toast(String s) {
        Toast.makeText(a, s, Toast.LENGTH_SHORT).show();
    }

    static String sizeLabel(long bytes) {
        if (bytes < 1024) return "0 KB";
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        return String.format(Locale.US, "%.1f MB", bytes / (1024.0 * 1024.0));
    }
}
