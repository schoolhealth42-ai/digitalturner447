package com.dtvradio.tuner;

import android.content.Context;
import android.util.LruCache;

import com.google.mlkit.common.model.DownloadConditions;
import com.google.mlkit.common.model.RemoteModelManager;
import com.google.mlkit.nl.languageid.LanguageIdentification;
import com.google.mlkit.nl.languageid.LanguageIdentifier;
import com.google.mlkit.nl.translate.TranslateLanguage;
import com.google.mlkit.nl.translate.TranslateRemoteModel;
import com.google.mlkit.nl.translate.Translation;
import com.google.mlkit.nl.translate.Translator;
import com.google.mlkit.nl.translate.TranslatorOptions;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/**
 * On-device translation to Arabic with ML Kit. Language packs (~30 MB each) are
 * downloaded once, then translation works offline. All callbacks run on the main thread.
 */
public final class Tr {
    private Tr() {}

    public interface Cb {
        /** result is null on failure. */
        void done(String result);
    }

    /** Source languages offered in settings: {code, Arabic label}. "" = automatic. */
    public static final String[][] SOURCES = {
            {"", "تلقائي (اكتشاف لغة القناة)"},
            {TranslateLanguage.ENGLISH, "الإنجليزية"}, {TranslateLanguage.FRENCH, "الفرنسية"},
            {TranslateLanguage.TURKISH, "التركية"}, {TranslateLanguage.SPANISH, "الإسبانية"},
            {TranslateLanguage.GERMAN, "الألمانية"}, {TranslateLanguage.URDU, "الأردية"},
            {TranslateLanguage.PERSIAN, "الفارسية"}, {TranslateLanguage.HINDI, "الهندية"},
            {TranslateLanguage.RUSSIAN, "الروسية"}, {TranslateLanguage.PORTUGUESE, "البرتغالية"},
            {TranslateLanguage.ITALIAN, "الإيطالية"}, {TranslateLanguage.INDONESIAN, "الإندونيسية"},
            {TranslateLanguage.CHINESE, "الصينية"}, {TranslateLanguage.JAPANESE, "اليابانية"},
            {TranslateLanguage.KOREAN, "الكورية"}
    };

    private static final Map<String, Translator> CLIENTS = new HashMap<>();
    private static final Set<String> READY = new HashSet<>();
    private static final LruCache<String, String> CACHE = new LruCache<>(4000);
    private static LanguageIdentifier ident;

    public static String cached(String src, String text) {
        return CACHE.get(src + "|" + text);
    }

    private static Translator client(String src) {
        Translator t = CLIENTS.get(src);
        if (t == null) {
            TranslatorOptions o = new TranslatorOptions.Builder()
                    .setSourceLanguage(src)
                    .setTargetLanguage(TranslateLanguage.ARABIC)
                    .build();
            t = Translation.getClient(o);
            CLIENTS.put(src, t);
        }
        return t;
    }

    private static DownloadConditions conditions(Context c) {
        DownloadConditions.Builder b = new DownloadConditions.Builder();
        if (Prefs.trWifiOnly(c)) b.requireWifi();
        return b.build();
    }

    /** Downloads the language pack (src -> Arabic) if needed. */
    public static void prepare(Context c, final String src, final Cb cb) {
        if (READY.contains(src)) {
            cb.done("ok");
            return;
        }
        client(src).downloadModelIfNeeded(conditions(c))
                .addOnSuccessListener(v -> {
                    READY.add(src);
                    cb.done("ok");
                })
                .addOnFailureListener(e -> cb.done(null));
    }

    public static void translate(Context c, final String src, final String text, final Cb cb) {
        if (text == null || text.trim().isEmpty() || src == null || src.isEmpty()) {
            cb.done(null);
            return;
        }
        if (src.equals(TranslateLanguage.ARABIC)) {
            cb.done(text);
            return;
        }
        final String key = src + "|" + text;
        String hit = CACHE.get(key);
        if (hit != null) {
            cb.done(hit);
            return;
        }
        final Translator t = client(src);
        final Runnable go = () -> t.translate(text)
                .addOnSuccessListener(r -> {
                    CACHE.put(key, r);
                    cb.done(r);
                })
                .addOnFailureListener(e -> cb.done(null));
        if (READY.contains(src)) go.run();
        else prepare(c, src, ok -> {
            if (ok == null) cb.done(null);
            else go.run();
        });
    }

    /** Detects the language of a text; returns an ML Kit language code or null. */
    public static void detect(String text, final Cb cb) {
        if (ident == null) ident = LanguageIdentification.getClient();
        ident.identifyLanguage(text)
                .addOnSuccessListener(tag -> cb.done("und".equals(tag) ? null : TranslateLanguage.fromLanguageTag(tag)))
                .addOnFailureListener(e -> cb.done(null));
    }

    /** True if the text has Latin letters (worth translating a channel name). */
    public static boolean hasLatin(String s) {
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if ((ch >= 'A' && ch <= 'Z') || (ch >= 'a' && ch <= 'z')) return true;
        }
        return false;
    }

    public static void deleteModels(final Cb cb) {
        final RemoteModelManager m = RemoteModelManager.getInstance();
        m.getDownloadedModels(TranslateRemoteModel.class)
                .addOnSuccessListener(models -> {
                    for (TranslateRemoteModel x : models) m.deleteDownloadedModel(x);
                    READY.clear();
                    cb.done(String.valueOf(models.size()));
                })
                .addOnFailureListener(e -> cb.done(null));
    }
}
