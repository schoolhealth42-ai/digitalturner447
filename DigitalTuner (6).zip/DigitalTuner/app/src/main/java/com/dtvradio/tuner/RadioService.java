package com.dtvradio.tuner;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

/** Foreground service that keeps radio alive with the screen off and shows a notification with Stop. */
public class RadioService extends Service {
    static final String CHANNEL = "radio_playback";
    static final int ID = 7101;
    static final String ACTION_STOP = "com.dtvradio.tuner.STOP";
    static volatile boolean running = false;

    public static void update(Context c, String title, String text, boolean playing) {
        Intent i = new Intent(c, RadioService.class);
        i.putExtra("title", title);
        i.putExtra("text", text);
        try {
            if (running) {
                // already in the foreground: just refresh the notification
                NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
                if (nm != null) nm.notify(ID, build(c, title, text));
            } else if (Build.VERSION.SDK_INT >= 26) {
                c.startForegroundService(i);
            } else {
                c.startService(i);
            }
        } catch (Exception ignored) {
            // background start not allowed: playback continues without the notification
        }
    }

    public static void stop(Context c) {
        if (!running) return;
        try { c.stopService(new Intent(c, RadioService.class)); } catch (Exception ignored) {}
    }

    static Notification build(Context c, String title, String text) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null && nm.getNotificationChannel(CHANNEL) == null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "تشغيل الراديو", NotificationManager.IMPORTANCE_LOW);
            ch.setShowBadge(false);
            nm.createNotificationChannel(ch);
        }
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        Intent open = new Intent(c, MainActivity.class);
        open.putExtra("tab", 1);
        open.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(c, 1, open, flags);
        Intent stop = new Intent(c, RadioService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(c, 2, stop, flags);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(c, CHANNEL)
                : new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("📻 " + title)
                .setContentText(text)
                .setContentIntent(openPi)
                .setOngoing(true)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .addAction(android.R.drawable.ic_media_pause, "⏹ إيقاف", stopPi);
        return b.build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            running = false;
            AudioPlayer.get().stop();
            stopForegroundCompat();
            stopSelf();
            return START_NOT_STICKY;
        }
        String title = intent == null ? "" : intent.getStringExtra("title");
        String text = intent == null ? "" : intent.getStringExtra("text");
        Notification n = build(this, title == null ? "" : title, text == null ? "" : text);
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
            } else {
                startForeground(ID, n);
            }
            running = true;
        } catch (Exception e) {
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    private void stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) stopForeground(Service.STOP_FOREGROUND_REMOVE);
        else stopForeground(true);
    }

    @Override
    public void onDestroy() {
        running = false;
        stopForegroundCompat();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
