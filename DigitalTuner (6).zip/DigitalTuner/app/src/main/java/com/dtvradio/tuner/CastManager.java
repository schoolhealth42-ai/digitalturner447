package com.dtvradio.tuner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.mediarouter.media.MediaRouteSelector;
import androidx.mediarouter.media.MediaRouter;

import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Everything about showing a channel on another screen:
 *  - Chromecast / Google TV / Android TV with Cast (Google Cast)
 *  - DLNA smart TVs (Samsung, LG, Sony…), Android receivers and TV boxes, and other phones
 *    running this app in receiver mode
 *  - Mirroring the whole phone screen, opening in another app, sharing the link, QR code
 */
public final class CastManager {
    private CastManager() {}

    public interface Listener { void onCastChanged(String deviceName); }

    private static Listener listener;
    private static String activeName = null;
    private static Dlna.Device activeDlna = null;
    private static Station pending = null;
    private static boolean pendingTv = true;
    private static boolean sessionListenerAdded = false;

    public static void setListener(Listener l) { listener = l; }
    public static boolean isCasting() { return activeName != null; }
    public static String activeName() { return activeName; }

    private static void fire() {
        if (listener != null) listener.onCastChanged(activeName);
    }

    // ---------------- Google Cast ----------------

    @SuppressWarnings("deprecation")
    static CastContext castContext(Context c) {
        try {
            return CastContext.getSharedInstance(c.getApplicationContext());
        } catch (Throwable t) {
            return null;   // no Google Play services (many receivers / TV boxes)
        }
    }

    private static void ensureSessionListener(final Context c) {
        final CastContext cc = castContext(c);
        if (cc == null || sessionListenerAdded) return;
        sessionListenerAdded = true;
        cc.getSessionManager().addSessionManagerListener(new SessionManagerListener<CastSession>() {
            @Override public void onSessionStarting(CastSession s) {}
            @Override public void onSessionStarted(CastSession s, String id) { loadPending(c, s); }
            @Override public void onSessionStartFailed(CastSession s, int e) {
                pending = null;
                Toast.makeText(c, "تعذّر الاتصال بجهاز Chromecast", Toast.LENGTH_SHORT).show();
            }
            @Override public void onSessionEnding(CastSession s) {}
            @Override public void onSessionEnded(CastSession s, int e) {
                if (activeDlna == null) { activeName = null; fire(); }
            }
            @Override public void onSessionResuming(CastSession s, String id) {}
            @Override public void onSessionResumed(CastSession s, boolean b) { loadPending(c, s); }
            @Override public void onSessionResumeFailed(CastSession s, int e) {}
            @Override public void onSessionSuspended(CastSession s, int r) {}
        }, CastSession.class);
    }

    private static void loadPending(Context c, CastSession session) {
        Station s = pending;
        pending = null;
        if (s == null || session == null) return;
        RemoteMediaClient rmc = session.getRemoteMediaClient();
        if (rmc == null) return;
        boolean tv = pendingTv;
        MediaMetadata md = new MediaMetadata(tv ? MediaMetadata.MEDIA_TYPE_MOVIE : MediaMetadata.MEDIA_TYPE_MUSIC_TRACK);
        md.putString(MediaMetadata.KEY_TITLE, s.name);
        md.putString(MediaMetadata.KEY_SUBTITLE, "الموالف الرقمي");
        String u = s.url.toLowerCase(Locale.ROOT);
        String type = u.contains(".m3u8") ? "application/x-mpegURL" : (tv ? "video/mp4" : "audio/mpeg");
        MediaInfo info = new MediaInfo.Builder(s.url)
                .setStreamType(MediaInfo.STREAM_TYPE_LIVE)
                .setContentType(type)
                .setMetadata(md)
                .build();
        rmc.load(new MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build());
        activeDlna = null;
        activeName = session.getCastDevice() != null ? session.getCastDevice().getFriendlyName() : "Chromecast";
        fire();
        Toast.makeText(c, "📺 يُعرض الآن على " + activeName, Toast.LENGTH_SHORT).show();
    }

    // ---------------- stop ----------------

    public static void stopCasting(Context c) {
        if (activeDlna != null) Dlna.stop(activeDlna);
        CastContext cc = castContext(c);
        if (cc != null) {
            try { cc.getSessionManager().endCurrentSession(true); } catch (Exception ignored) {}
        }
        activeDlna = null;
        activeName = null;
        fire();
    }

    // ---------------- device chooser ----------------

    private static class Target {
        final String label;
        final MediaRouter.RouteInfo route;
        final Dlna.Device dlna;
        Target(String label, MediaRouter.RouteInfo route, Dlna.Device dlna) {
            this.label = label;
            this.route = route;
            this.dlna = dlna;
        }
        @Override public String toString() { return label; }
    }

    /** Shows nearby screens (Chromecast + DLNA + receivers running this app) plus other ways to share. */
    public static void showDevices(final Activity a, final Station s, final boolean tv) {
        if (s == null) {
            Toast.makeText(a, "اختر قناة أو محطة أولاً", Toast.LENGTH_SHORT).show();
            return;
        }
        final List<Target> targets = new ArrayList<>();
        final List<Dlna.Device> dlnaFound = new ArrayList<>();
        final ArrayAdapter<Target> ad = new ArrayAdapter<>(a, android.R.layout.simple_list_item_1, new ArrayList<Target>());

        ScrollView scroll = new ScrollView(a);
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(a, 16);
        box.setPadding(p, Ui.dp(a, 8), p, Ui.dp(a, 8));
        scroll.addView(box);

        TextView what = Ui.text(a, (tv ? "📺 " : "📻 ") + s.name, 15, Ui.ACCENT, true);
        box.addView(what);
        LinearLayout statusRow = Ui.row(a);
        final ProgressBar pb = new ProgressBar(a);
        statusRow.addView(pb, new LinearLayout.LayoutParams(Ui.dp(a, 20), Ui.dp(a, 20)));
        final TextView status = Ui.text(a, "  جارِ البحث عن الشاشات على نفس شبكة الواي فاي…", 13, Ui.SUB, false);
        statusRow.addView(status);
        box.addView(statusRow, Ui.full(a, 8));

        final ListView lv = new ListView(a);
        lv.setAdapter(ad);
        box.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 200)));

        TextView more = Ui.text(a, "طرق أخرى", 13, Ui.SUB, true);
        more.setPadding(0, Ui.dp(a, 10), 0, Ui.dp(a, 4));
        box.addView(more);
        Button mirror = Ui.button(a, "🪞 مشاركة شاشة الجوال كاملة (Screen Mirroring)", Ui.CARD2);
        Button other = Ui.button(a, "📱 فتح في تطبيق آخر (VLC، MX Player…)", Ui.CARD2);
        Button share = Ui.button(a, "🔗 مشاركة رابط البث", Ui.CARD2);
        Button qr = Ui.button(a, "🔳 رمز QR لفتحه على جوال آخر", Ui.CARD2);
        for (Button b : new Button[]{mirror, other, share, qr}) {
            b.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
            b.setTextSize(14 * Ui.SCALE);
            box.addView(b, Ui.full(a, 6));
        }
        TextView hint = Ui.text(a,
                "💡 لجهاز ريسيفر أندرويد (مثل غزال) أو تلفاز أندرويد أو جوال آخر: ثبّت هذا التطبيق عليه وفعّل «وضع الاستقبال» من الإعدادات، فيظهر هنا تلقائياً.",
                12, Ui.SUB, false);
        hint.setPadding(0, Ui.dp(a, 10), 0, 0);
        box.addView(hint);

        final AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("📡 العرض على شاشة أخرى")
                .setView(scroll)
                .setNegativeButton("إغلاق", null)
                .create();

        // --- Chromecast routes ---
        final CastContext cc = castContext(a);
        MediaRouteSelector sel = null;
        MediaRouter router = null;
        if (cc != null) {
            ensureSessionListener(a);
            try {
                sel = cc.getMergedSelector();
                router = MediaRouter.getInstance(a);
            } catch (Throwable ignored) {}
        }
        final MediaRouter fRouter = router;
        final MediaRouteSelector fSel = sel;
        final Runnable rebuild = () -> {
            targets.clear();
            if (fRouter != null && fSel != null) {
                for (MediaRouter.RouteInfo r : fRouter.getRoutes()) {
                    if (r.isDefault() || !r.isEnabled() || !r.matchesSelector(fSel)) continue;
                    targets.add(new Target("📺  " + r.getName() + "   • Chromecast", r, null));
                }
            }
            for (Dlna.Device dev : dlnaFound) {
                String icon = dev.ours ? "📲  " : "🖥  ";
                String kind = dev.ours ? "   • وضع الاستقبال" : "   • DLNA";
                targets.add(new Target(icon + dev.name + kind, null, dev));
            }
            ad.clear();
            ad.addAll(targets);
        };
        final MediaRouter.Callback cb = new MediaRouter.Callback() {
            @Override public void onRouteAdded(MediaRouter r, MediaRouter.RouteInfo route) { rebuild.run(); }
            @Override public void onRouteChanged(MediaRouter r, MediaRouter.RouteInfo route) { rebuild.run(); }
            @Override public void onRouteRemoved(MediaRouter r, MediaRouter.RouteInfo route) { rebuild.run(); }
        };
        if (fRouter != null && fSel != null) {
            fRouter.addCallback(fSel, cb, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN);
        }
        d.setOnDismissListener(x -> {
            if (fRouter != null) fRouter.removeCallback(cb);
        });

        // --- DLNA ---
        final Runnable scan = new Runnable() {
            @Override public void run() {
                pb.setVisibility(android.view.View.VISIBLE);
                status.setText("  جارِ البحث عن الشاشات على نفس شبكة الواي فاي…");
                Dlna.discover(a, 6000, dev -> {
                    for (Dlna.Device x : dlnaFound) if (x.location.equals(dev.location)) return;
                    dlnaFound.add(dev);
                    rebuild.run();
                }, () -> {
                    pb.setVisibility(android.view.View.GONE);
                    status.setText(ad.getCount() == 0
                            ? "  لم يُعثر على شاشات. تأكد أن التلفاز/الريسيفر يعمل وعلى نفس الواي فاي، ثم اضغط «إعادة البحث»."
                            : "  اختر الشاشة:");
                });
            }
        };
        d.setButton(AlertDialog.BUTTON_NEUTRAL, "🔄 إعادة البحث", (x, w) -> {});
        rebuild.run();
        scan.run();

        lv.setOnItemClickListener((parent, view, pos, id) -> {
            Target t = ad.getItem(pos);
            if (t == null) return;
            d.dismiss();
            if (t.route != null && fRouter != null) {
                pending = s;
                pendingTv = tv;
                CastSession cur = cc != null ? cc.getSessionManager().getCurrentCastSession() : null;
                if (cur != null && cur.isConnected() && t.route.isSelected()) {
                    loadPending(a, cur);
                } else {
                    Toast.makeText(a, "جارِ الاتصال بـ " + t.route.getName() + "…", Toast.LENGTH_SHORT).show();
                    fRouter.selectRoute(t.route);
                }
            } else if (t.dlna != null) {
                final Dlna.Device dev = t.dlna;
                Toast.makeText(a, "جارِ الإرسال إلى " + dev.name + "…", Toast.LENGTH_SHORT).show();
                Dlna.play(dev, s, tv, (ok, msg) -> {
                    if (ok) {
                        activeDlna = dev;
                        activeName = dev.name;
                        fire();
                        Toast.makeText(a, "🖥 يُعرض الآن على " + dev.name, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(a, "رفض الجهاز تشغيل هذا البث — جرّب قناة أخرى أو «مشاركة الشاشة»", Toast.LENGTH_LONG).show();
                    }
                });
            }
        });
        mirror.setOnClickListener(v -> { d.dismiss(); openMirroring(a); });
        other.setOnClickListener(v -> { d.dismiss(); openWith(a, s, tv); });
        share.setOnClickListener(v -> { d.dismiss(); shareLink(a, s); });
        qr.setOnClickListener(v -> { d.dismiss(); showQr(a, s); });

        d.show();
        // the neutral button must not close the dialog
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
            dlnaFound.clear();
            rebuild.run();
            scan.run();
        });
    }

    // ---------------- long-press menu for a channel / station ----------------

    public static void showOptions(final Activity a, final Station s, final boolean tv, final String favKey, final Runnable afterFav) {
        final boolean fav = Favorites.has(a, favKey, s.url);
        String[] items = {
                fav ? "☆ إزالة من المفضلة" : "★ إضافة إلى المفضلة",
                "📡 عرض على التلفاز / شاشة أخرى",
                "🔗 مشاركة الرابط",
                "🔳 رمز QR لجوال آخر",
                "📱 فتح في تطبيق آخر"
        };
        new AlertDialog.Builder(a).setTitle(s.name).setItems(items, (d, w) -> {
            switch (w) {
                case 0:
                    boolean now = Favorites.toggle(a, favKey, s);
                    Toast.makeText(a, now ? "أُضيفت إلى المفضلة ★" : "حُذفت من المفضلة", Toast.LENGTH_SHORT).show();
                    if (afterFav != null) afterFav.run();
                    break;
                case 1: showDevices(a, s, tv); break;
                case 2: shareLink(a, s); break;
                case 3: showQr(a, s); break;
                default: openWith(a, s, tv); break;
            }
        }).show();
    }

    // ---------------- other ways ----------------

    public static void openMirroring(Activity a) {
        String[] actions = {"android.settings.CAST_SETTINGS", "android.settings.WIFI_DISPLAY_SETTINGS",
                Settings.ACTION_WIRELESS_SETTINGS};
        for (String act : actions) {
            try {
                a.startActivity(new Intent(act));
                Toast.makeText(a, "اختر التلفاز من القائمة لعرض شاشة الجوال كاملة", Toast.LENGTH_LONG).show();
                return;
            } catch (Exception ignored) {}
        }
        new AlertDialog.Builder(a).setTitle("🪞 مشاركة الشاشة")
                .setMessage("افتح لوحة الإعدادات السريعة في الجوال واختر «Smart View» أو «عرض الشاشة» أو «Cast»، ثم اختر التلفاز.")
                .setPositiveButton("حسناً", null).show();
    }

    public static void openWith(Activity a, Station s, boolean tv) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setDataAndType(Uri.parse(s.url), tv ? "video/*" : "audio/*");
            i.putExtra("title", s.name);
            a.startActivity(Intent.createChooser(i, "فتح باستخدام"));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(a, "لا يوجد تطبيق مشغّل آخر على الجهاز", Toast.LENGTH_SHORT).show();
        }
    }

    public static void shareLink(Activity a, Station s) {
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("text/plain");
        i.putExtra(Intent.EXTRA_SUBJECT, s.name);
        i.putExtra(Intent.EXTRA_TEXT, "📺 " + s.name + "\n" + s.url + "\n\nعبر تطبيق «الموالف الرقمي»");
        a.startActivity(Intent.createChooser(i, "مشاركة الرابط"));
    }

    public static void showQr(Activity a, Station s) {
        int size = Ui.dp(a, 260);
        Bitmap bmp = qr(s.url, size);
        if (bmp == null) {
            Toast.makeText(a, "الرابط طويل جداً لرمز QR", Toast.LENGTH_SHORT).show();
            return;
        }
        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        int p = Ui.dp(a, 16);
        box.setPadding(p, p, p, p);
        ImageView iv = new ImageView(a);
        iv.setImageBitmap(bmp);
        iv.setBackgroundColor(0xFFFFFFFF);
        int pad = Ui.dp(a, 8);
        iv.setPadding(pad, pad, pad, pad);
        box.addView(iv, new LinearLayout.LayoutParams(size + pad * 2, size + pad * 2));
        TextView t = Ui.text(a, "امسح الرمز بكاميرا الجوال الآخر لفتح «" + s.name + "» مباشرة", 13, Ui.SUB, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(0, Ui.dp(a, 10), 0, 0);
        box.addView(t);
        new AlertDialog.Builder(a).setTitle("🔳 " + s.name).setView(box).setPositiveButton("إغلاق", null).show();
    }

    static Bitmap qr(String text, int size) {
        try {
            Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            hints.put(EncodeHintType.MARGIN, 1);
            BitMatrix m = new QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints);
            int w = m.getWidth(), h = m.getHeight();
            int[] px = new int[w * h];
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) px[y * w + x] = m.get(x, y) ? 0xFF000000 : 0xFFFFFFFF;
            }
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.RGB_565);
            b.setPixels(px, 0, w, 0, 0, w, h);
            return b;
        } catch (Throwable t) {
            return null;
        }
    }
}
