package com.dtvradio.tuner;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.View;
import android.widget.ImageView;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Minimal logo loader: memory cache, downsampling, and a text fallback when a logo fails. */
public final class ImageLoader {
    private ImageLoader() {}

    private static final LruCache<String, Bitmap> MEM = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    private static final Set<String> FAILED = Collections.synchronizedSet(new HashSet<String>());
    private static final ExecutorService EX = Executors.newFixedThreadPool(3);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /** Shows the logo in {@code iv}; while loading or on failure shows {@code fallback}. */
    public static void load(final ImageView iv, final String url, final View fallback, final int sizePx) {
        iv.setTag(url);
        if (url == null || url.isEmpty() || !url.startsWith("http") || FAILED.contains(url)) {
            iv.setVisibility(View.GONE);
            fallback.setVisibility(View.VISIBLE);
            return;
        }
        Bitmap cached = MEM.get(url);
        if (cached != null) {
            iv.setImageBitmap(cached);
            iv.setVisibility(View.VISIBLE);
            fallback.setVisibility(View.GONE);
            return;
        }
        iv.setImageDrawable(null);
        iv.setVisibility(View.GONE);
        fallback.setVisibility(View.VISIBLE);
        EX.execute(() -> {
            final Bitmap bm = download(url, sizePx);
            MAIN.post(() -> {
                if (bm == null) {
                    FAILED.add(url);
                    return;
                }
                MEM.put(url, bm);
                if (url.equals(iv.getTag())) {
                    iv.setImageBitmap(bm);
                    iv.setVisibility(View.VISIBLE);
                    fallback.setVisibility(View.GONE);
                }
            });
        });
    }

    private static Bitmap download(String url, int target) {
        try {
            byte[] data = Net.fetchBytes(url, 1_500_000);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(data, 0, data.length, o);
            if (o.outWidth <= 0 || o.outHeight <= 0) return null;
            int sample = 1;
            while (o.outWidth / (sample * 2) >= target && o.outHeight / (sample * 2) >= target) sample *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options();
            o2.inSampleSize = sample;
            return BitmapFactory.decodeByteArray(data, 0, data.length, o2);
        } catch (Throwable t) {
            return null;
        }
    }
}
