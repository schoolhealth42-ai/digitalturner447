package com.dtvradio.tuner;

import android.content.Context;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** List adapter for channels / stations with a text filter and a sub-category filter. */
public class StationAdapter extends BaseAdapter {
    private static final int[] COLORS = {
            0xFF0EA5E9, 0xFF22C55E, 0xFFF59E0B, 0xFFEF4444, 0xFFA855F7, 0xFF14B8A6, 0xFFEC4899, 0xFF6366F1
    };

    private final Context c;
    private final String favKey;
    private List<Station> all = new ArrayList<>();
    private List<Station> shown = new ArrayList<>();
    private String filter = "";
    private String group = "";
    private String activeUrl = "";
    private Set<String> favs = new HashSet<>();

    public StationAdapter(Context c, String favKey) {
        this.c = c;
        this.favKey = favKey;
    }

    public void setData(List<Station> data) {
        all = data == null ? new ArrayList<Station>() : data;
        logos = Prefs.showLogos(c);
        trNames = favKey.equals("tv") && Prefs.trNames(c);
        refreshFavs();
        apply();
    }

    public void setFilter(String f) {
        filter = f == null ? "" : f.trim().toLowerCase(Locale.ROOT);
        apply();
    }

    /** Show only stations whose group-title contains this group ("" = all). */
    public void setGroup(String g) {
        group = g == null ? "" : g;
        apply();
    }

    public void setActive(String url) {
        activeUrl = url == null ? "" : url;
        notifyDataSetChanged();
    }

    public void refreshFavs() {
        favs = new HashSet<>();
        for (Station s : Favorites.load(c, favKey)) favs.add(s.url);
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }

    public List<Station> shown() { return shown; }
    public int totalCount() { return all.size(); }

    private boolean inGroup(Station s) {
        if (group.isEmpty()) return true;
        for (String g : s.group.split(";")) if (g.trim().equalsIgnoreCase(group)) return true;
        return false;
    }

    private void apply() {
        List<Station> res = new ArrayList<>();
        for (Station s : all) {
            if (!inGroup(s)) continue;
            String tr = trNames ? Tr.cached("en", cleanName(s.name)) : null;
            if (filter.isEmpty()
                    || s.name.toLowerCase(Locale.ROOT).contains(filter)
                    || (tr != null && tr.contains(filter))
                    || s.info.toLowerCase(Locale.ROOT).contains(filter)) {
                res.add(s);
            }
        }
        shown = res;
        notifyDataSetChanged();
    }

    /** "Al Jazeera English (1080p) [Geo-blocked]" -> "Al Jazeera English" */
    static String cleanName(String n) {
        return n.replaceAll("\\([^)]*\\)", "").replaceAll("\\[[^\\]]*\\]", "").trim();
    }

    @Override public int getCount() { return shown.size(); }
    @Override public Object getItem(int position) { return shown.get(position); }
    @Override public long getItemId(int position) { return position; }

    private boolean logos = true;
    private boolean trNames = false;
    private final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());
    private final java.util.Set<String> pendingTr = new HashSet<>();
    private final Runnable refresh = this::notifyDataSetChanged;

    private static class Holder {
        TextView avatar, name, info, star;
        android.widget.ImageView logo;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Holder h;
        LinearLayout row;
        if (convertView instanceof LinearLayout && convertView.getTag() instanceof Holder) {
            row = (LinearLayout) convertView;
            h = (Holder) convertView.getTag();
        } else {
            row = Ui.row(c);
            int p = Ui.dp(c, 10);
            row.setPadding(p, p, p, p);
            row.setLayoutParams(new AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            h = new Holder();

            h.avatar = Ui.text(c, "", 18, 0xFFFFFFFF, true);
            h.avatar.setGravity(Gravity.CENTER);
            int sz = Ui.dp(c, 44);
            android.widget.FrameLayout box = new android.widget.FrameLayout(c);
            box.addView(h.avatar, new android.widget.FrameLayout.LayoutParams(sz, sz));
            h.logo = new android.widget.ImageView(c);
            h.logo.setScaleType(android.widget.ImageView.ScaleType.FIT_CENTER);
            h.logo.setBackground(Ui.round(c, 0xFFE2E8F0, 10));
            int lp = Ui.dp(c, 4);
            h.logo.setPadding(lp, lp, lp, lp);
            h.logo.setVisibility(View.GONE);
            box.addView(h.logo, new android.widget.FrameLayout.LayoutParams(sz, sz));
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(sz, sz);
            ap.setMarginEnd(Ui.dp(c, 12));
            row.addView(box, ap);

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            h.name = Ui.text(c, "", 16, Ui.TEXT, true);
            h.name.setSingleLine(true);
            h.name.setEllipsize(TextUtils.TruncateAt.END);
            h.info = Ui.text(c, "", 12.5f, Ui.SUB, false);
            h.info.setSingleLine(true);
            h.info.setEllipsize(TextUtils.TruncateAt.END);
            col.addView(h.name);
            col.addView(h.info);
            row.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            h.star = Ui.text(c, "", 18, Ui.ACCENT2, false);
            h.star.setPadding(Ui.dp(c, 8), 0, Ui.dp(c, 4), 0);
            row.addView(h.star);
            row.setTag(h);
        }

        Station s = shown.get(position);
        String initial = s.name.isEmpty() ? "?" : s.name.substring(0, 1).toUpperCase(Locale.ROOT);
        h.avatar.setText(initial);
        int color = COLORS[(s.name.hashCode() & 0x7fffffff) % COLORS.length];
        h.avatar.setBackground(Ui.round(c, color, 22));
        if (logos) ImageLoader.load(h.logo, s.logo, h.avatar, Ui.dp(c, 44));
        else { h.logo.setVisibility(View.GONE); h.avatar.setVisibility(View.VISIBLE); }
        String shownName = s.name;
        String shownInfo = s.info;
        if (trNames && Tr.hasLatin(s.name)) {
            String clean = cleanName(s.name);
            String ar = Tr.cached("en", clean);
            if (ar != null && !ar.equalsIgnoreCase(clean)) {
                shownName = ar;
                shownInfo = clean + (s.info.isEmpty() ? "" : " • " + s.info);
            } else if (ar == null && pendingTr.add(clean)) {
                Tr.translate(c, "en", clean, r -> {
                    pendingTr.remove(clean);
                    if (r != null) {
                        ui.removeCallbacks(refresh);
                        ui.postDelayed(refresh, 250);
                    }
                });
            }
        }
        h.name.setText(shownName);
        h.info.setText(shownInfo);
        h.info.setVisibility(shownInfo.isEmpty() ? View.GONE : View.VISIBLE);
        h.star.setText(favs.contains(s.url) ? "★" : "");
        boolean active = s.url.equals(activeUrl);
        row.setBackground(active ? Ui.round(c, Ui.CARD2, 12) : null);
        h.name.setTextColor(active ? Ui.ACCENT : Ui.TEXT);
        h.name.setTypeface(Typeface.DEFAULT_BOLD);
        return row;
    }
}
