package com.dtvradio.tuner;

import org.json.JSONException;
import org.json.JSONObject;

/** A TV channel, internet radio station, or a saved over-the-air frequency. */
public class Station {
    public String name = "";
    public String url = "";
    public String info = "";
    public String group = "";
    public String band = "";
    public long freq = 0;
    /** Optional HTTP headers some streams require (from #EXTVLCOPT in M3U). */
    public String ua = "";
    public String referer = "";
    /** Video height parsed from the name, e.g. "(480p)" -> 480. 0 = unknown. */
    public int height = 0;
    /** Channel / station logo URL (tvg-logo or favicon). */
    public String logo = "";

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("name", name);
        o.put("url", url);
        o.put("info", info);
        o.put("group", group);
        o.put("band", band);
        o.put("freq", freq);
        o.put("ua", ua);
        o.put("ref", referer);
        o.put("h", height);
        o.put("logo", logo);
        return o;
    }

    public static Station fromJson(JSONObject o) {
        Station s = new Station();
        s.name = o.optString("name");
        s.url = o.optString("url");
        s.info = o.optString("info");
        s.group = o.optString("group");
        s.band = o.optString("band");
        s.freq = o.optLong("freq");
        s.ua = o.optString("ua");
        s.referer = o.optString("ref");
        s.height = o.optInt("h");
        s.logo = o.optString("logo");
        return s;
    }
}
