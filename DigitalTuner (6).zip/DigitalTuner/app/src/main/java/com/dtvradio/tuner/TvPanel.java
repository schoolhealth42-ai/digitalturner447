package com.dtvradio.tuner;

import android.app.AlertDialog;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Internet TV with three levels of navigation:
 *   1) section  (countries / regions / categories / languages / all / favorites / my lists)
 *   2) item     (any country of the world, a region, a category, a language …)
 *   3) sub-category chips built from the loaded channels' group-title
 * Several playlists are merged and de-duplicated to get as many channels as possible.
 */
public class TvPanel extends LinearLayout {
    static final String BASE = "https://iptv-org.github.io/iptv/";
    static final String API = "https://iptv-org.github.io/api/";
    static final String FREE_TV = "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8";

    static final String[] SECTIONS = {"🌍 الدول", "🗺 المناطق", "🗂 التصنيفات", "🗣 اللغات", "🌐 الكل", "★ المفضلة", "📂 قائمتي"};
    static final int SEC_COUNTRY = 0, SEC_REGION = 1, SEC_CAT = 2, SEC_LANG = 3, SEC_ALL = 4, SEC_FAV = 5, SEC_MINE = 6;

    static final String[] ARAB = {"sa", "ae", "kw", "qa", "bh", "om", "ye", "iq", "jo", "sy", "lb", "ps",
            "eg", "sd", "ly", "tn", "dz", "ma", "mr", "so", "dj", "km"};
    static final String[] POPULAR = {"tr", "ir", "pk", "in", "af", "id", "my", "uk", "us", "ca", "fr", "de",
            "es", "it", "nl", "ru", "br", "mx", "ar", "au", "jp", "kr", "cn", "ng", "za"};

    static final String[][] CATEGORIES = {
            {"news", "📰 أخبار"}, {"sports", "⚽ رياضة"}, {"kids", "🧸 أطفال"}, {"animation", "🎨 رسوم متحركة"},
            {"movies", "🎬 أفلام"}, {"series", "📺 مسلسلات"}, {"entertainment", "🎭 ترفيه"},
            {"religious", "🕌 ديني"}, {"music", "🎵 موسيقى"}, {"documentary", "🌍 وثائقي"},
            {"education", "🎓 تعليمي"}, {"culture", "🏛 ثقافة"}, {"general", "📡 عام"}, {"family", "👨‍👩‍👧 عائلي"},
            {"comedy", "😂 كوميديا"}, {"cooking", "🍳 طبخ"}, {"lifestyle", "✨ نمط حياة"}, {"travel", "✈️ سفر"},
            {"science", "🔬 علوم"}, {"business", "💼 اقتصاد"}, {"auto", "🚗 سيارات"}, {"outdoor", "🏕 مغامرات"},
            {"classic", "🎞 كلاسيكي"}, {"weather", "⛅ طقس"}, {"legislative", "🏛 برلماني"},
            {"shop", "🛍 تسوق"}, {"relax", "🌿 استرخاء"}
    };

    static final String[][] LANGUAGES = {
            {"ara", "العربية"}, {"eng", "الإنجليزية"}, {"fra", "الفرنسية"}, {"tur", "التركية"},
            {"urd", "الأردية"}, {"fas", "الفارسية"}, {"kur", "الكردية"}, {"pus", "البشتو"}, {"hin", "الهندية"},
            {"ben", "البنغالية"}, {"tam", "التاميلية"}, {"pan", "البنجابية"}, {"ind", "الإندونيسية"},
            {"msa", "الملايوية"}, {"tgl", "الفلبينية"}, {"tha", "التايلاندية"}, {"vie", "الفيتنامية"},
            {"zho", "الصينية"}, {"jpn", "اليابانية"}, {"kor", "الكورية"}, {"spa", "الإسبانية"},
            {"por", "البرتغالية"}, {"deu", "الألمانية"}, {"ita", "الإيطالية"}, {"nld", "الهولندية"},
            {"pol", "البولندية"}, {"ron", "الرومانية"}, {"ell", "اليونانية"}, {"rus", "الروسية"},
            {"ukr", "الأوكرانية"}, {"aze", "الأذرية"}, {"sqi", "الألبانية"}, {"srp", "الصربية"},
            {"swe", "السويدية"}, {"heb", "العبرية"}, {"swa", "السواحيلية"}, {"amh", "الأمهرية"}, {"som", "الصومالية"}
    };

    static final String[][] ALL = {
            {"all:iptv", "🌐 كل قنوات العالم (iptv-org)"}, {"all:freetv", "📡 Free-TV"}, {"all:both", "➕ المصدران معاً"}
    };

    static final Map<String, String> REGION_AR = new HashMap<>();
    static {
        String[][] r = {
                {"ARAB", "العالم العربي"}, {"MENA", "الشرق الأوسط وشمال أفريقيا"}, {"MIDEAST", "الشرق الأوسط"},
                {"MAGHREB", "المغرب العربي"}, {"GCC", "الخليج العربي"}, {"AFR", "أفريقيا"}, {"ASIA", "آسيا"},
                {"EUR", "أوروبا"}, {"EU", "الاتحاد الأوروبي"}, {"AMER", "الأمريكتان"}, {"LATAM", "أمريكا اللاتينية"},
                {"LAC", "أمريكا اللاتينية والكاريبي"}, {"NAM", "أمريكا الشمالية"}, {"OCE", "أوقيانوسيا"},
                {"WW", "العالم كله"}, {"CIS", "رابطة الدول المستقلة"}, {"SAS", "جنوب آسيا"},
                {"SSA", "أفريقيا جنوب الصحراء"}, {"WAF", "غرب أفريقيا"}, {"CAS", "آسيا الوسطى"},
                {"BALKAN", "البلقان"}, {"NORD", "دول الشمال الأوروبي"}, {"CARIB", "الكاريبي"},
                {"HISPAM", "أمريكا الناطقة بالإسبانية"}, {"ASEAN", "رابطة آسيان"}, {"APAC", "آسيا والمحيط الهادئ"},
                {"EMEA", "أوروبا والشرق الأوسط وأفريقيا"}, {"CEE", "وسط وشرق أوروبا"}, {"BENELUX", "البنلوكس"},
                {"NORAM", "أمريكا الشمالية"}, {"SAM", "أمريكا الجنوبية"}, {"CAM", "أمريكا الوسطى"},
                {"EAF", "شرق أفريقيا"}, {"SAF", "جنوب أفريقيا"}, {"CAF", "وسط أفريقيا"}, {"NAF", "شمال أفريقيا"},
                {"EAS", "شرق آسيا"}, {"SEA", "جنوب شرق آسيا"}, {"WAS", "غرب آسيا"}, {"DACH", "ألمانيا والنمسا وسويسرا"},
                {"INT", "دولية"}
        };
        for (String[] x : r) REGION_AR.put(x[0], x[1]);
    }
    static final String[] FALLBACK_REGIONS = {"ARAB", "MENA", "AFR", "ASIA", "EUR", "AMER", "LATAM", "WW"};

    static final Map<String, String> GROUP_AR = new HashMap<>();
    static {
        for (String[] c : CATEGORIES) GROUP_AR.put(c[0], c[1]);
        GROUP_AR.put("undefined", "❔ غير مصنّف");
        GROUP_AR.put("other", "❔ أخرى");
    }

    static final Pattern RES = Pattern.compile("\\((\\d{3,4})[pP]\\)");
    static final Locale AR = new Locale("ar");

    /** Regions loaded once from the iptv-org API: {code, label}. */
    static List<String[]> regions = null;

    private final MainActivity a;
    private final StationAdapter adapter;
    private final Button[] sectionBtns = new Button[SECTIONS.length];
    private final HorizontalScrollView itemScroll, groupScroll;
    private final LinearLayout itemRow, groupRow;
    private final TextView info;
    private final ProgressBar loading;
    private final Button sortBtn;

    private int section = 0;
    private String currentKey = "home";
    private final Map<Integer, String> lastItem = new HashMap<>();
    private List<Station> loaded = new ArrayList<>();
    private int hiddenCount = 0;
    private int seq = 0;
    private boolean loadedOnce = false;
    private boolean sortLight;

    public TvPanel(MainActivity act) {
        super(act);
        a = act;
        adapter = new StationAdapter(act, "tv");
        sortLight = Prefs.sortLight(act);
        setOrientation(VERTICAL);
        int p = Ui.dp(act, 10);
        setPadding(p, p / 2, p, 0);

        // level 1: sections
        HorizontalScrollView hs = new HorizontalScrollView(act);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout secRow = Ui.row(act);
        for (int i = 0; i < SECTIONS.length; i++) {
            final int idx = i;
            Button b = Ui.chipButton(act, SECTIONS[i]);
            b.setOnClickListener(v -> openSection(idx));
            sectionBtns[i] = b;
            secRow.addView(b, Ui.wrap(act, 2));
        }
        hs.addView(secRow);
        addView(hs);

        // level 2: items of the section
        itemScroll = new HorizontalScrollView(act);
        itemScroll.setHorizontalScrollBarEnabled(false);
        itemRow = Ui.row(act);
        itemScroll.addView(itemRow);
        addView(itemScroll);

        // level 3: sub-categories from the loaded list
        groupScroll = new HorizontalScrollView(act);
        groupScroll.setHorizontalScrollBarEnabled(false);
        groupRow = Ui.row(act);
        groupScroll.addView(groupRow);
        addView(groupScroll);

        LinearLayout searchRow = Ui.row(act);
        EditText search = new EditText(act);
        search.setHint("🔍 ابحث عن قناة…");
        search.setHintTextColor(Ui.SUB);
        search.setTextColor(Ui.TEXT);
        search.setSingleLine(true);
        search.setBackground(Ui.round(act, Ui.CARD, 12));
        search.setPadding(Ui.dp(act, 14), Ui.dp(act, 9), Ui.dp(act, 14), Ui.dp(act, 9));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { adapter.setFilter(s.toString()); updateInfo(); }
            public void afterTextChanged(Editable e) {}
        });
        searchRow.addView(search, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button random = Ui.chipButton(act, "🎲");
        random.setOnClickListener(v -> playRandom());
        searchRow.addView(random, Ui.wrap(act, 3));
        sortBtn = Ui.chipButton(act, "⚡ الأخف");
        Ui.chip(act, sortBtn, sortLight);
        sortBtn.setOnClickListener(v -> {
            sortLight = !sortLight;
            Prefs.edit(a).putBoolean("sortlight", sortLight).apply();
            Ui.chip(a, sortBtn, sortLight);
            showList(loaded);
            Toast.makeText(a, sortLight ? "ترتيب: القنوات الأخف (الأقل جودة) أولاً — مناسب للنت الضعيف" : "الترتيب الافتراضي", Toast.LENGTH_SHORT).show();
        });
        searchRow.addView(sortBtn, Ui.wrap(act, 3));
        addView(searchRow, Ui.full(act, 4));

        LinearLayout status = Ui.row(act);
        loading = new ProgressBar(act);
        int sz = Ui.dp(act, 18);
        status.addView(loading, new LayoutParams(sz, sz));
        info = Ui.text(act, "", 12.5f, Ui.SUB, false);
        info.setPadding(Ui.dp(act, 8), 0, Ui.dp(act, 8), 0);
        status.addView(info);
        addView(status, Ui.full(act, 6));

        ListView list = new ListView(act);
        list.setDivider(null);
        list.setFastScrollEnabled(true);
        list.setAdapter(adapter);
        list.setOnItemClickListener((parent, view, pos, id) -> play(pos));
        list.setOnItemLongClickListener((parent, view, pos, id) -> {
            Station s = adapter.shown().get(pos);
            CastManager.showOptions(a, s, true, "tv", () -> {
                if (currentKey.equals("fav")) loadKey("fav");
                else {
                    adapter.refreshFavs();
                    adapter.notifyDataSetChanged();
                }
            });
            return true;
        });
        addView(list, new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        section = Prefs.p(act).getInt("tvsec2", 0);
        if (section < 0 || section >= SECTIONS.length) section = 0;
        for (int i = 0; i < SECTIONS.length; i++) {
            String k = Prefs.p(act).getString("tvitem2_" + i, null);
            if (k != null) lastItem.put(i, k);
        }
    }

    public void onShown() {
        adapter.refreshFavs();
        if (!loadedOnce) openSection(section);
        else adapter.notifyDataSetChanged();
    }

    public void reload() {
        sortLight = Prefs.sortLight(a);
        Ui.chip(a, sortBtn, sortLight);
        if (loadedOnce) loadKey(currentKey);
    }

    private void play(int pos) {
        List<Station> shown = adapter.shown();
        if (pos < 0 || pos >= shown.size()) return;
        adapter.setActive(shown.get(pos).url);
        PlayerActivity.playlist = new ArrayList<>(shown);
        PlayerActivity.index = pos;
        a.startActivity(new Intent(a, PlayerActivity.class));
    }

    private void playRandom() {
        int n = adapter.getCount();
        if (n == 0) return;
        int pos = (int) (Math.random() * n);
        Toast.makeText(a, "🎲 " + adapter.shown().get(pos).name, Toast.LENGTH_SHORT).show();
        play(pos);
    }

    // ---------------- countries helpers ----------------

    /** Flag emoji from a 2-letter code. */
    static String flag(String code) {
        String cc = code.toUpperCase(Locale.ROOT);
        if (cc.equals("UK")) cc = "GB";
        if (cc.length() != 2 || !Character.isLetter(cc.charAt(0)) || !Character.isLetter(cc.charAt(1))) return "🏳";
        int first = 0x1F1E6 + (cc.charAt(0) - 'A');
        int second = 0x1F1E6 + (cc.charAt(1) - 'A');
        return new String(Character.toChars(first)) + new String(Character.toChars(second));
    }

    /** Arabic country name from the system (works for every country, offline). */
    static String countryAr(String code) {
        String cc = code.toUpperCase(Locale.ROOT);
        if (cc.equals("UK")) cc = "GB";
        String n = new Locale("", cc).getDisplayCountry(AR);
        return (n == null || n.isEmpty() || n.equalsIgnoreCase(cc)) ? cc : n;
    }

    static String countryEn(String code) {
        String cc = code.toUpperCase(Locale.ROOT);
        if (cc.equals("UK")) cc = "GB";
        return new Locale("", cc).getDisplayCountry(Locale.ENGLISH);
    }

    /** iptv-org playlist file code (it uses "uk" for the United Kingdom). */
    static String playlistCode(String code) {
        String cc = code.toLowerCase(Locale.ROOT);
        return cc.equals("gb") ? "uk" : cc;
    }

    private String countryLabel(String code) {
        return flag(code) + " " + countryAr(code);
    }

    private List<String> pickedCountries() {
        List<String> out = new ArrayList<>();
        for (String s : Prefs.p(a).getString("tvpicked", "").split(",")) if (!s.trim().isEmpty()) out.add(s.trim());
        return out;
    }

    private void rememberPicked(String code) {
        List<String> l = pickedCountries();
        l.remove(code);
        l.add(0, code);
        while (l.size() > 8) l.remove(l.size() - 1);
        Prefs.edit(a).putString("tvpicked", android.text.TextUtils.join(",", l)).apply();
    }

    /** Searchable list of every country in the world. */
    private void showWorldPicker() {
        final List<String[]> all = new ArrayList<>();
        for (String cc : Locale.getISOCountries()) {
            String code = cc.toLowerCase(Locale.ROOT);
            all.add(new String[]{code, countryAr(code)});
        }
        final Collator col = Collator.getInstance(AR);
        Collections.sort(all, (x, y) -> col.compare(x[1], y[1]));
        final List<String> labels = new ArrayList<>();
        final Map<String, String> byLabel = new HashMap<>();
        for (String[] c : all) {
            String l = flag(c[0]) + "  " + c[1];
            labels.add(l);
            byLabel.put(l, c[0]);
        }

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(a, 12);
        box.setPadding(p, p, p, 0);
        EditText q = new EditText(a);
        q.setHint("🔍 اكتب اسم الدولة…");
        q.setSingleLine(true);
        box.addView(q);
        ListView lv = new ListView(a);
        final ArrayAdapter<String> ad = new ArrayAdapter<>(a, android.R.layout.simple_list_item_1, new ArrayList<>(labels));
        lv.setAdapter(ad);
        box.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(a, 420)));

        final AlertDialog d = new AlertDialog.Builder(a)
                .setTitle("🌍 كل دول العالم (" + labels.size() + ")")
                .setView(box)
                .setNegativeButton("إغلاق", null)
                .create();
        q.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int af) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) {
                String f = s.toString().trim().toLowerCase(Locale.ROOT);
                ad.clear();
                for (int i = 0; i < all.size(); i++) {
                    String[] cc = all.get(i);
                    if (f.isEmpty() || cc[1].toLowerCase(Locale.ROOT).contains(f)
                            || countryEn(cc[0]).toLowerCase(Locale.ROOT).contains(f)) {
                        ad.add(labels.get(i));
                    }
                }
            }
            public void afterTextChanged(Editable e) {}
        });
        lv.setOnItemClickListener((parent, view, pos, id) -> {
            String code = byLabel.get(ad.getItem(pos));
            d.dismiss();
            if (code == null) return;
            rememberPicked(code);
            lastItem.put(SEC_COUNTRY, "c:" + code);
            Prefs.edit(a).putString("tvitem2_" + SEC_COUNTRY, "c:" + code).apply();
            openSection(SEC_COUNTRY);
        });
        d.show();
    }

    // ---------------- navigation ----------------

    private List<String[]> itemsOf(int sec) {
        List<String[]> items = new ArrayList<>();
        switch (sec) {
            case SEC_COUNTRY: {
                String home = playlistCode(Prefs.country(a));
                items.add(new String[]{"home", "🏠 بلدي " + flag(home)});
                items.add(new String[]{"pick", "🌍 كل دول العالم…"});
                items.add(new String[]{"merge:arab", "🌙 كل القنوات العربية"});
                Set<String> shown = new HashSet<>();
                for (String c : pickedCountries()) {
                    if (shown.add(c)) items.add(new String[]{"c:" + c, countryLabel(c)});
                }
                for (String c : ARAB) if (shown.add(c)) items.add(new String[]{"c:" + c, countryLabel(c)});
                for (String c : POPULAR) if (shown.add(c)) items.add(new String[]{"c:" + c, countryLabel(c)});
                return items;
            }
            case SEC_REGION: {
                List<String[]> rs = regions;
                if (rs == null) {
                    rs = new ArrayList<>();
                    for (String r : FALLBACK_REGIONS) rs.add(new String[]{r, REGION_AR.get(r)});
                }
                for (String[] r : rs) items.add(new String[]{"r:" + r[0].toLowerCase(Locale.ROOT), "🗺 " + r[1]});
                return items;
            }
            case SEC_CAT:
                for (String[] c : CATEGORIES) items.add(new String[]{"cat:" + c[0], c[1]});
                return items;
            case SEC_LANG:
                for (String[] c : LANGUAGES) items.add(new String[]{"l:" + c[0], c[1]});
                return items;
            case SEC_ALL:
                for (String[] c : ALL) items.add(new String[]{c[0], c[1]});
                return items;
            default:
                return null;
        }
    }

    private void loadRegionsIfNeeded() {
        if (regions != null) return;
        Net.get(API + "regions.json", new Net.Callback() {
            @Override public void ok(String body) {
                List<String[]> out = new ArrayList<>();
                try {
                    JSONArray arr = new JSONArray(body);
                    for (int i = 0; i < arr.length(); i++) {
                        JSONObject o = arr.getJSONObject(i);
                        String code = o.optString("code").toUpperCase(Locale.ROOT);
                        if (code.isEmpty()) continue;
                        String ar = REGION_AR.get(code);
                        out.add(new String[]{code, ar != null ? ar : o.optString("name", code)});
                    }
                } catch (Exception ignored) {}
                if (out.isEmpty()) return;
                // Arabic-named (well known) regions first
                List<String[]> sorted = new ArrayList<>();
                for (String[] r : out) if (REGION_AR.containsKey(r[0])) sorted.add(r);
                for (String[] r : out) if (!REGION_AR.containsKey(r[0])) sorted.add(r);
                regions = sorted;
                if (section == SEC_REGION) openSection(SEC_REGION);
            }
            @Override public void err(String message) {}
        });
    }

    private void openSection(int sec) {
        section = sec;
        Prefs.edit(a).putInt("tvsec2", sec).apply();
        for (int i = 0; i < sectionBtns.length; i++) Ui.chip(a, sectionBtns[i], i == sec);
        itemRow.removeAllViews();
        if (sec == SEC_REGION) loadRegionsIfNeeded();
        List<String[]> items = itemsOf(sec);
        if (items == null) {
            itemScroll.setVisibility(GONE);
            loadKey(sec == SEC_FAV ? "fav" : "custom");
            return;
        }
        itemScroll.setVisibility(VISIBLE);
        String want = lastItem.containsKey(sec) ? lastItem.get(sec) : items.get(0)[0];
        if (want.equals("pick")) want = "home";
        boolean found = false;
        for (String[] it : items) if (it[0].equals(want)) found = true;
        if (!found) want = items.get(0)[0];
        Button selected = null;
        for (String[] it : items) {
            final String key = it[0];
            Button b = Ui.chipButton(a, it[1]);
            b.setTextSize(13 * Ui.SCALE);
            b.setMinimumHeight(Ui.dp(a, 34));
            b.setTag(key);
            if (key.equals("pick")) {
                b.setOnClickListener(v -> showWorldPicker());
                b.setBackground(Ui.round(a, Ui.ACCENT2, 20));
                b.setTextColor(Ui.DARK_TEXT);
            } else {
                b.setOnClickListener(v -> selectItem(key));
                Ui.chip(a, b, key.equals(want));
            }
            if (key.equals(want)) selected = b;
            itemRow.addView(b, Ui.wrap(a, 2));
        }
        if (selected != null) {
            final Button sb = selected;
            itemScroll.post(() -> itemScroll.smoothScrollTo(Math.max(0, sb.getLeft() - Ui.dp(a, 40)), 0));
        }
        loadKey(want);
    }

    private void selectItem(String key) {
        lastItem.put(section, key);
        Prefs.edit(a).putString("tvitem2_" + section, key).apply();
        for (int i = 0; i < itemRow.getChildCount(); i++) {
            View v = itemRow.getChildAt(i);
            if (v instanceof Button && !"pick".equals(v.getTag())) Ui.chip(a, (Button) v, key.equals(v.getTag()));
        }
        loadKey(key);
    }

    private String[] urlsFor(String key) {
        boolean extra = Prefs.extraSources(a);
        if (key.equals("home")) key = "c:" + playlistCode(Prefs.country(a));
        if (key.equals("merge:arab")) {
            return extra
                    ? new String[]{BASE + "languages/ara.m3u", BASE + "regions/arab.m3u", FREE_TV}
                    : new String[]{BASE + "languages/ara.m3u", BASE + "regions/arab.m3u"};
        }
        if (key.startsWith("r:")) return new String[]{BASE + "regions/" + key.substring(2) + ".m3u"};
        if (key.startsWith("c:")) {
            String c = playlistCode(key.substring(2));
            return extra ? new String[]{BASE + "countries/" + c + ".m3u", FREE_TV}
                    : new String[]{BASE + "countries/" + c + ".m3u"};
        }
        if (key.startsWith("cat:")) return new String[]{BASE + "categories/" + key.substring(4) + ".m3u"};
        if (key.startsWith("l:")) return new String[]{BASE + "languages/" + key.substring(2) + ".m3u"};
        if (key.equals("all:iptv")) return new String[]{BASE + "index.m3u"};
        if (key.equals("all:freetv")) return new String[]{FREE_TV};
        if (key.equals("all:both")) return new String[]{BASE + "index.m3u", FREE_TV};
        if (key.equals("custom")) {
            String u = Prefs.customM3u(a).trim();
            if (u.isEmpty()) return new String[0];
            List<String> parts = new ArrayList<>();
            for (String s : u.split("[\\s,]+")) if (s.trim().startsWith("http")) parts.add(s.trim());
            return parts.toArray(new String[0]);
        }
        return new String[0];
    }

    /**
     * For a country (or the Arab merge) the Free-TV list is filtered to the matching
     * countries by its group-title; other lists are used whole.
     */
    private List<String> freeTvFilter(String key) {
        if (key.equals("home")) key = "c:" + Prefs.country(a);
        List<String> names = new ArrayList<>();
        if (key.startsWith("c:")) {
            names.add(countryEn(key.substring(2)).toLowerCase(Locale.ROOT));
        } else if (key.equals("merge:arab")) {
            for (String c : ARAB) names.add(countryEn(c).toLowerCase(Locale.ROOT));
            names.add("arab");
        } else {
            return null;
        }
        return names;
    }

    private void loadKey(String key) {
        loadedOnce = true;
        currentKey = key;
        final int my = ++seq;
        groupRow.removeAllViews();
        groupScroll.setVisibility(GONE);
        adapter.setGroup("");

        if (key.equals("fav")) {
            loading.setVisibility(GONE);
            showList(Favorites.load(a, "tv"));
            if (loaded.isEmpty()) info.setText("لا توجد قنوات مفضلة بعد — اضغط مطولاً على أي قناة لإضافتها");
            return;
        }
        final String[] urls = urlsFor(key);
        if (urls.length == 0) {
            loading.setVisibility(GONE);
            showList(new ArrayList<Station>());
            info.setText("أضف روابط قوائم M3U الخاصة بك من الإعدادات ← «قوائمي الخاصة»");
            return;
        }
        final List<String> ftFilter = freeTvFilter(key);
        loading.setVisibility(VISIBLE);
        info.setText(urls.length > 1 ? "جارِ تحميل ودمج " + urls.length + " مصادر…" : "جارِ تحميل القنوات…");
        showList(new ArrayList<Station>());
        Net.<List<Station>>getAll(urls, bodies -> {
            List<Station> merged = new ArrayList<>();
            Set<String> seen = new HashSet<>();
            for (int i = 0; i < bodies.size(); i++) {
                String b = bodies.get(i);
                if (b == null) continue;
                boolean isFreeTv = FREE_TV.equals(urls[i]);
                for (Station s : parseM3u(b)) {
                    if (isFreeTv && ftFilter != null && !matchesAny(s.group, ftFilter)) continue;
                    if (seen.add(s.url)) merged.add(s);
                }
            }
            return merged;
        }, (value, failed) -> {
            if (my != seq) return;
            loading.setVisibility(GONE);
            if (value == null || value.isEmpty()) {
                showList(new ArrayList<Station>());
                info.setText(failed == urls.length
                        ? "تعذّر التحميل — تأكد من الإنترنت ثم أعد المحاولة"
                        : "لا توجد قنوات متاحة هنا حالياً — جرّب دولة أو تصنيفاً آخر");
                return;
            }
            showList(value);
            buildGroups(value);
        });
    }

    static boolean matchesAny(String group, List<String> names) {
        String g = group.toLowerCase(Locale.ROOT);
        for (String n : names) if (!n.isEmpty() && g.contains(n)) return true;
        return false;
    }

    private void showList(List<Station> list) {
        loaded = list == null ? new ArrayList<Station>() : list;
        boolean hideGeo = Prefs.hideGeo(a), hide247 = Prefs.hideNot247(a);
        List<Station> view = new ArrayList<>();
        hiddenCount = 0;
        for (Station s : loaded) {
            if ((hideGeo && s.name.contains("[Geo-blocked]")) || (hide247 && s.name.contains("[Not 24/7]"))) {
                hiddenCount++;
                continue;
            }
            view.add(s);
        }
        if (sortLight) Collections.sort(view, (x, y) -> Integer.compare(weight(x), weight(y)));
        adapter.setData(view);
        updateInfo();
    }

    /** Lower = lighter stream. Unknown resolution is treated like 576p. */
    private static int weight(Station s) {
        return s.height > 0 ? s.height : 576;
    }

    private void buildGroups(List<Station> list) {
        final Map<String, Integer> counts = new LinkedHashMap<>();
        for (Station s : list) {
            for (String g : s.group.split(";")) {
                g = g.trim();
                if (g.isEmpty()) continue;
                Integer n = counts.get(g);
                counts.put(g, n == null ? 1 : n + 1);
            }
        }
        if (counts.size() < 2) return;
        List<String> keys = new ArrayList<>(counts.keySet());
        Collections.sort(keys, (x, y) -> counts.get(y) - counts.get(x));
        if (keys.size() > 50) keys = keys.subList(0, 50);

        groupRow.removeAllViews();
        addGroupChip("", "📋 الكل (" + list.size() + ")", true);
        for (String g : keys) addGroupChip(g, groupLabel(g) + " (" + counts.get(g) + ")", false);
        groupScroll.setVisibility(VISIBLE);
        groupScroll.scrollTo(0, 0);
    }

    private void addGroupChip(final String g, String label, boolean on) {
        Button b = Ui.chipButton(a, label);
        b.setTextSize(12 * Ui.SCALE);
        b.setMinimumHeight(Ui.dp(a, 30));
        b.setPadding(Ui.dp(a, 12), 0, Ui.dp(a, 12), 0);
        b.setTag(g);
        Ui.chip(a, b, on);
        b.setOnClickListener(v -> {
            for (int i = 0; i < groupRow.getChildCount(); i++) {
                View c = groupRow.getChildAt(i);
                if (c instanceof Button) Ui.chip(a, (Button) c, g.equals(c.getTag()));
            }
            adapter.setGroup(g);
            updateInfo();
        });
        groupRow.addView(b, Ui.wrap(a, 2));
    }

    static String groupLabel(String g) {
        String ar = GROUP_AR.get(g.toLowerCase(Locale.ROOT));
        return ar != null ? ar : g;
    }

    private void updateInfo() {
        if (currentKey.equals("fav") && adapter.totalCount() == 0) return;
        int n = adapter.getCount();
        int total = adapter.totalCount();
        String s = n == total ? n + " قناة" : n + " من " + total + " قناة";
        if (hiddenCount > 0) s += " • أُخفيت " + hiddenCount;
        info.setText(s + " • اضغط مطولاً للخيارات والعرض على التلفاز");
    }

    // ---------------- M3U parsing ----------------

    static List<Station> parseM3u(String body) {
        List<Station> out = new ArrayList<>();
        String name = null, group = "", ua = "", ref = "", logo = "";
        for (String raw : body.split("\n")) {
            String line = raw.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                group = attr(line, "group-title");
                logo = attr(line, "tvg-logo");
                ua = attr(line, "http-user-agent");
                if (ua.isEmpty()) ua = attr(line, "user-agent");
                ref = attr(line, "http-referrer");
                boolean inQ = false;
                int comma = -1;
                for (int i = 0; i < line.length(); i++) {
                    char ch = line.charAt(i);
                    if (ch == '"') inQ = !inQ;
                    else if (ch == ',' && !inQ) { comma = i; break; }
                }
                name = comma >= 0 ? line.substring(comma + 1).trim() : null;
            } else if (line.startsWith("#EXTVLCOPT:http-user-agent=")) {
                ua = line.substring("#EXTVLCOPT:http-user-agent=".length()).trim();
            } else if (line.startsWith("#EXTVLCOPT:http-referrer=")) {
                ref = line.substring("#EXTVLCOPT:http-referrer=".length()).trim();
            } else if (!line.startsWith("#")) {
                if (!line.startsWith("http") && !line.startsWith("rtmp") && !line.startsWith("rtsp")) {
                    name = null;
                    continue;
                }
                Station s = new Station();
                s.name = (name == null || name.isEmpty()) ? line : name;
                s.url = line;
                s.group = group;
                s.ua = ua;
                s.referer = ref;
                s.logo = logo;
                s.band = "TV";
                Matcher m = RES.matcher(s.name);
                if (m.find()) {
                    try { s.height = Integer.parseInt(m.group(1)); } catch (Exception ignored) {}
                }
                StringBuilder sb = new StringBuilder();
                for (String g : group.split(";")) {
                    if (g.trim().isEmpty()) continue;
                    if (sb.length() > 0) sb.append(" • ");
                    sb.append(groupLabel(g.trim()));
                }
                if (s.height > 0 && s.height <= 480) sb.append(sb.length() > 0 ? " • " : "").append("⚡ خفيفة");
                if (s.height >= 1080) sb.append(sb.length() > 0 ? " • " : "").append("HD");
                s.info = sb.toString();
                out.add(s);
                name = null;
                group = "";
                ua = "";
                ref = "";
                logo = "";
            }
        }
        return out;
    }

    static String attr(String line, String key) {
        int i = line.indexOf(" " + key + "=\"");
        if (i < 0) return "";
        i += key.length() + 3;
        int j = line.indexOf('"', i);
        return j > i ? line.substring(i, j) : "";
    }
}
