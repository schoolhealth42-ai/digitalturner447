package com.dtvradio.tuner;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Single shared player for internet radio. Keeps playing in the background
 * (wake lock + foreground notification) and supports a sleep timer.
 */
public final class AudioPlayer {
    public interface Listener {
        void onPlayerStatus(String status, boolean playing);
    }

    private static AudioPlayer inst;

    public static synchronized AudioPlayer get() {
        if (inst == null) inst = new AudioPlayer();
        return inst;
    }

    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Listener> listeners = new ArrayList<>();
    private Context ctx;
    private MediaPlayer mp;
    private Station current;
    private boolean playing;
    private String lastStatus = "";
    private long sleepAt = 0;

    public void addListener(Listener l) { if (!listeners.contains(l)) listeners.add(l); }
    public void removeListener(Listener l) { listeners.remove(l); }
    public void clearListeners() { listeners.clear(); }
    public Station current() { return current; }
    public boolean isPlaying() { return playing; }
    public String lastStatus() { return lastStatus; }
    public boolean isActive() { return mp != null; }

    public void play(Context c, Station s) {
        ctx = c.getApplicationContext();
        release();
        current = s;
        History.add(ctx, "radio", s);
        final MediaPlayer m = new MediaPlayer();
        mp = m;
        status("جارِ الاتصال…", false);
        try {
            m.setAudioStreamType(AudioManager.STREAM_MUSIC);
            m.setWakeMode(ctx, PowerManager.PARTIAL_WAKE_LOCK);
            m.setDataSource(s.url);
            m.setOnPreparedListener(p -> {
                if (p != mp) return;
                p.start();
                playing = true;
                status("▶ يعمل الآن", true);
            });
            m.setOnErrorListener((p, what, extra) -> {
                if (p == mp) {
                    playing = false;
                    status("تعذّر تشغيل هذه المحطة — جرّب محطة أخرى", false);
                }
                return true;
            });
            m.setOnCompletionListener(p -> {
                if (p == mp) {
                    playing = false;
                    status("انتهى البث", false);
                }
            });
            m.prepareAsync();
        } catch (Exception e) {
            status("رابط غير صالح", false);
        }
    }

    /** Replays the current station (after an error or a stop). */
    public void replay(Context c) {
        if (current != null) play(c, current);
    }

    /** Stop requested by the user (or by another source taking audio). */
    public void stop() {
        boolean had = mp != null;
        release();
        cancelSleep();
        if (ctx != null) RadioService.stop(ctx);
        if (had) status("متوقف", false);
    }

    private void release() {
        playing = false;
        if (mp != null) {
            try { mp.stop(); } catch (Exception ignored) {}
            try { mp.release(); } catch (Exception ignored) {}
            mp = null;
        }
    }

    // ---------------- sleep timer ----------------

    private final Runnable sleepRun = () -> {
        sleepAt = 0;
        stop();
        status("⏾ انتهى مؤقت النوم — تم الإيقاف", false);
    };

    public void setSleep(int minutes) {
        cancelSleep();
        if (minutes <= 0) return;
        sleepAt = System.currentTimeMillis() + minutes * 60_000L;
        h.postDelayed(sleepRun, minutes * 60_000L);
    }

    public void cancelSleep() {
        h.removeCallbacks(sleepRun);
        sleepAt = 0;
    }

    /** Minutes left on the sleep timer, or 0 if none. */
    public int sleepMinutesLeft() {
        if (sleepAt == 0) return 0;
        long ms = sleepAt - System.currentTimeMillis();
        return ms <= 0 ? 0 : (int) Math.ceil(ms / 60_000.0);
    }

    // ---------------- status ----------------

    private void status(String s, boolean p) {
        lastStatus = s;
        if (ctx != null && current != null && mp != null && Prefs.bgPlayback(ctx)) {
            RadioService.update(ctx, current.name, s, p);
        }
        for (Listener l : new ArrayList<>(listeners)) l.onPlayerStatus(s, p);
    }
}
