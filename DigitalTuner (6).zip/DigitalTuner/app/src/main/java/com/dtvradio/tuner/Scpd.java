package com.dtvradio.tuner;

/** Service descriptions (SCPD) published by receiver mode so any DLNA controller can use it. */
final class Scpd {
    private Scpd() {}

    /**
     * actions: each entry is {"ActionName", "in Arg StateVar", "out Arg StateVar", ...}
     * vars:    each entry is {"StateVar", "dataType"}
     */
    private static String build(String[][] actions, String[][] vars) {
        StringBuilder b = new StringBuilder("<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<scpd xmlns=\"urn:schemas-upnp-org:service-1-0\"><specVersion><major>1</major><minor>0</minor></specVersion><actionList>");
        for (String[] a : actions) {
            b.append("<action><name>").append(a[0]).append("</name><argumentList>");
            for (int i = 1; i < a.length; i++) {
                String[] p = a[i].split(" ");
                b.append("<argument><name>").append(p[1]).append("</name><direction>").append(p[0])
                        .append("</direction><relatedStateVariable>").append(p[2]).append("</relatedStateVariable></argument>");
            }
            b.append("</argumentList></action>");
        }
        b.append("</actionList><serviceStateTable>");
        for (String[] v : vars) {
            b.append("<stateVariable sendEvents=\"").append(v[0].equals("LastChange") ? "yes" : "no").append("\"><name>")
                    .append(v[0]).append("</name><dataType>").append(v[1]).append("</dataType></stateVariable>");
        }
        b.append("</serviceStateTable></scpd>");
        return b.toString();
    }

    static String avTransport() {
        String id = "in InstanceID A_ARG_TYPE_InstanceID";
        return build(new String[][]{
                {"SetAVTransportURI", id, "in CurrentURI AVTransportURI", "in CurrentURIMetaData AVTransportURIMetaData"},
                {"Play", id, "in Speed TransportPlaySpeed"},
                {"Stop", id},
                {"Pause", id},
                {"Seek", id, "in Unit A_ARG_TYPE_SeekMode", "in Target A_ARG_TYPE_SeekTarget"},
                {"GetTransportInfo", id, "out CurrentTransportState TransportState",
                        "out CurrentTransportStatus TransportStatus", "out CurrentSpeed TransportPlaySpeed"},
                {"GetPositionInfo", id, "out Track CurrentTrack", "out TrackDuration CurrentTrackDuration",
                        "out TrackMetaData CurrentTrackMetaData", "out TrackURI CurrentTrackURI",
                        "out RelTime RelativeTimePosition", "out AbsTime AbsoluteTimePosition",
                        "out RelCount RelativeCounterPosition", "out AbsCount AbsoluteCounterPosition"},
                {"GetMediaInfo", id, "out NrTracks NumberOfTracks", "out MediaDuration CurrentMediaDuration",
                        "out CurrentURI AVTransportURI", "out CurrentURIMetaData AVTransportURIMetaData",
                        "out NextURI NextAVTransportURI", "out NextURIMetaData NextAVTransportURIMetaData",
                        "out PlayMedium PlaybackStorageMedium", "out RecordMedium RecordStorageMedium",
                        "out WriteStatus RecordMediumWriteStatus"},
                {"GetTransportSettings", id, "out PlayMode CurrentPlayMode", "out RecQualityMode CurrentRecordQualityMode"},
                {"GetCurrentTransportActions", id, "out Actions CurrentTransportActions"},
                {"GetDeviceCapabilities", id, "out PlayMedia PossiblePlaybackStorageMedia",
                        "out RecMedia PossibleRecordStorageMedia", "out RecQualityModes PossibleRecordQualityModes"}
        }, new String[][]{
                {"A_ARG_TYPE_InstanceID", "ui4"}, {"AVTransportURI", "string"}, {"AVTransportURIMetaData", "string"},
                {"NextAVTransportURI", "string"}, {"NextAVTransportURIMetaData", "string"},
                {"TransportPlaySpeed", "string"}, {"TransportState", "string"}, {"TransportStatus", "string"},
                {"A_ARG_TYPE_SeekMode", "string"}, {"A_ARG_TYPE_SeekTarget", "string"},
                {"CurrentTrack", "ui4"}, {"CurrentTrackDuration", "string"}, {"CurrentTrackMetaData", "string"},
                {"CurrentTrackURI", "string"}, {"RelativeTimePosition", "string"}, {"AbsoluteTimePosition", "string"},
                {"RelativeCounterPosition", "i4"}, {"AbsoluteCounterPosition", "i4"}, {"NumberOfTracks", "ui4"},
                {"CurrentMediaDuration", "string"}, {"PlaybackStorageMedium", "string"}, {"RecordStorageMedium", "string"},
                {"RecordMediumWriteStatus", "string"}, {"CurrentPlayMode", "string"}, {"CurrentRecordQualityMode", "string"},
                {"CurrentTransportActions", "string"}, {"PossiblePlaybackStorageMedia", "string"},
                {"PossibleRecordStorageMedia", "string"}, {"PossibleRecordQualityModes", "string"}, {"LastChange", "string"}
        });
    }

    static String renderingControl() {
        String id = "in InstanceID A_ARG_TYPE_InstanceID";
        return build(new String[][]{
                {"GetVolume", id, "in Channel A_ARG_TYPE_Channel", "out CurrentVolume Volume"},
                {"SetVolume", id, "in Channel A_ARG_TYPE_Channel", "in DesiredVolume Volume"},
                {"GetMute", id, "in Channel A_ARG_TYPE_Channel", "out CurrentMute Mute"},
                {"SetMute", id, "in Channel A_ARG_TYPE_Channel", "in DesiredMute Mute"}
        }, new String[][]{
                {"A_ARG_TYPE_InstanceID", "ui4"}, {"A_ARG_TYPE_Channel", "string"},
                {"Volume", "ui2"}, {"Mute", "boolean"}, {"LastChange", "string"}
        });
    }

    static String connectionManager() {
        return build(new String[][]{
                {"GetProtocolInfo", "out Source SourceProtocolInfo", "out Sink SinkProtocolInfo"},
                {"GetCurrentConnectionIDs", "out ConnectionIDs CurrentConnectionIDs"},
                {"GetCurrentConnectionInfo", "in ConnectionID A_ARG_TYPE_ConnectionID", "out RcsID A_ARG_TYPE_RcsID",
                        "out AVTransportID A_ARG_TYPE_AVTransportID", "out ProtocolInfo A_ARG_TYPE_ProtocolInfo",
                        "out PeerConnectionManager A_ARG_TYPE_ConnectionManager",
                        "out PeerConnectionID A_ARG_TYPE_ConnectionID", "out Direction A_ARG_TYPE_Direction",
                        "out Status A_ARG_TYPE_ConnectionStatus"}
        }, new String[][]{
                {"SourceProtocolInfo", "string"}, {"SinkProtocolInfo", "string"}, {"CurrentConnectionIDs", "string"},
                {"A_ARG_TYPE_ConnectionID", "i4"}, {"A_ARG_TYPE_RcsID", "i4"}, {"A_ARG_TYPE_AVTransportID", "i4"},
                {"A_ARG_TYPE_ProtocolInfo", "string"}, {"A_ARG_TYPE_ConnectionManager", "string"},
                {"A_ARG_TYPE_Direction", "string"}, {"A_ARG_TYPE_ConnectionStatus", "string"}
        });
    }
}
