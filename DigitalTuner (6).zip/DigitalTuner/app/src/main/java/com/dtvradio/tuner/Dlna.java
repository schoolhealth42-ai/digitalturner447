package com.dtvradio.tuner;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * DLNA / UPnP sender: finds smart TVs, Android receivers and players on the same Wi-Fi
 * (SSDP) and tells them to play a stream (AVTransport SOAP).
 */
public final class Dlna {
    private Dlna() {}

    public static class Device {
        public String name = "";
        public String location = "";
        public String controlUrl = "";
        public String serviceType = "urn:schemas-upnp-org:service:AVTransport:1";
        public String manufacturer = "";
        /** True when the device is another copy of this app in receiver mode. */
        public boolean ours = false;
    }

    public interface Found { void on(Device d); }
    public interface Done { void on(boolean ok, String message); }

    static final String GROUP = "239.255.255.250";
    private static final ExecutorService EX = Executors.newCachedThreadPool();
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    /** Searches the local network for about {@code timeoutMs}; calls {@code found} for each renderer. */
    public static void discover(final Context c, final int timeoutMs, final Found found, final Runnable finished) {
        EX.execute(() -> {
            WifiManager.MulticastLock lock = null;
            DatagramSocket sock = null;
            try {
                WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    lock = wm.createMulticastLock("dlna-discover");
                    lock.setReferenceCounted(false);
                    lock.acquire();
                }
            } catch (Exception ignored) {}
            Set<String> seen = new HashSet<>();
            try {
                sock = new DatagramSocket();
                sock.setSoTimeout(700);
                InetAddress group = InetAddress.getByName(GROUP);
                String[] sts = {"urn:schemas-upnp-org:service:AVTransport:1", "urn:schemas-upnp-org:device:MediaRenderer:1"};
                for (int r = 0; r < 2; r++) {
                    for (String st : sts) {
                        String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\nST: "
                                + st + "\r\nUSER-AGENT: Android UPnP/1.0 DigitalTuner/3.2\r\n\r\n";
                        byte[] b = msg.getBytes("UTF-8");
                        sock.send(new DatagramPacket(b, b.length, group, 1900));
                    }
                }
                long end = System.currentTimeMillis() + timeoutMs;
                byte[] buf = new byte[4096];
                while (System.currentTimeMillis() < end) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    try {
                        sock.receive(p);
                    } catch (SocketTimeoutException e) {
                        continue;
                    }
                    String resp = new String(p.getData(), 0, p.getLength(), "UTF-8");
                    String loc = header(resp, "LOCATION");
                    if (loc == null || !seen.add(loc)) continue;
                    final Device d = describe(loc);
                    if (d != null) MAIN.post(() -> found.on(d));
                }
            } catch (Exception ignored) {
            } finally {
                if (sock != null) sock.close();
                if (lock != null) try { lock.release(); } catch (Exception ignored) {}
                MAIN.post(finished);
            }
        });
    }

    static String header(String msg, String name) {
        for (String line : msg.split("\r?\n")) {
            int i = line.indexOf(':');
            if (i > 0 && line.substring(0, i).trim().equalsIgnoreCase(name)) return line.substring(i + 1).trim();
        }
        return null;
    }

    static String tag(String xml, String name) {
        Matcher m = Pattern.compile("<(?:[\\w-]+:)?" + name + "(?:\\s[^>]*)?>(.*?)</(?:[\\w-]+:)?" + name + ">",
                Pattern.DOTALL | Pattern.CASE_INSENSITIVE).matcher(xml);
        return m.find() ? unesc(m.group(1).trim()) : null;
    }

    private static Device describe(String location) {
        try {
            String xml = Net.fetch(location);
            Device d = new Device();
            d.location = location;
            String n = tag(xml, "friendlyName");
            d.name = n == null ? location : n;
            String mf = tag(xml, "manufacturer");
            d.manufacturer = mf == null ? "" : mf;
            d.ours = "DigitalTuner".equals(d.manufacturer);
            String base = tag(xml, "URLBase");
            if (base == null || base.isEmpty()) base = location;
            for (String block : xml.split("(?i)<service>")) {
                String type = tag(block, "serviceType");
                if (type == null || !type.contains("AVTransport")) continue;
                String control = tag(block, "controlURL");
                if (control == null) continue;
                d.serviceType = type;
                d.controlUrl = new URL(new URL(base), control).toString();
                return d;
            }
        } catch (Exception ignored) {}
        return null;
    }

    static String esc(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    static String unesc(String s) {
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&");
    }

    private static void soap(Device d, String action, String args) throws IOException {
        String body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
                + "<s:Body><u:" + action + " xmlns:u=\"" + d.serviceType + "\">" + args + "</u:" + action + "></s:Body></s:Envelope>";
        HttpURLConnection c = (HttpURLConnection) new URL(d.controlUrl).openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(8000);
        c.setDoOutput(true);
        c.setRequestMethod("POST");
        c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
        c.setRequestProperty("SOAPACTION", "\"" + d.serviceType + "#" + action + "\"");
        byte[] b = body.getBytes("UTF-8");
        c.setFixedLengthStreamingMode(b.length);
        OutputStream out = c.getOutputStream();
        out.write(b);
        out.close();
        int code = c.getResponseCode();
        try {
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in != null) in.close();
        } catch (Exception ignored) {}
        c.disconnect();
        if (code >= 400) throw new IOException("HTTP " + code);
    }

    static String mimeFor(Station s, boolean tv) {
        String u = s.url.toLowerCase(Locale.ROOT);
        if (u.contains(".m3u8")) return tv ? "application/vnd.apple.mpegurl" : "audio/mpegurl";
        if (!tv) return u.contains(".aac") ? "audio/aac" : "audio/mpeg";
        if (u.contains(".mp4")) return "video/mp4";
        if (u.contains(".ts")) return "video/mp2t";
        return "video/mp4";
    }

    /** Sends a stream to the device and starts playback. */
    public static void play(final Device d, final Station s, final boolean tv, final Done done) {
        EX.execute(() -> {
            try {
                try { soap(d, "Stop", "<InstanceID>0</InstanceID>"); } catch (IOException ignored) {}
                String mime = mimeFor(s, tv);
                String didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" "
                        + "xmlns:dc=\"http://purl.org/dc/elements/1.1/\" xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">"
                        + "<item id=\"0\" parentID=\"-1\" restricted=\"1\"><dc:title>" + esc(s.name) + "</dc:title>"
                        + "<upnp:class>" + (tv ? "object.item.videoItem.videoBroadcast" : "object.item.audioItem.audioBroadcast") + "</upnp:class>"
                        + "<res protocolInfo=\"http-get:*:" + mime + ":*\">" + esc(s.url) + "</res></item></DIDL-Lite>";
                soap(d, "SetAVTransportURI", "<InstanceID>0</InstanceID><CurrentURI>" + esc(s.url)
                        + "</CurrentURI><CurrentURIMetaData>" + esc(didl) + "</CurrentURIMetaData>");
                try { soap(d, "Play", "<InstanceID>0</InstanceID><Speed>1</Speed>"); } catch (IOException ignored) {}
                MAIN.post(() -> done.on(true, null));
            } catch (Exception e) {
                final String m = e.getMessage();
                MAIN.post(() -> done.on(false, m));
            }
        });
    }

    public static void stop(final Device d) {
        EX.execute(() -> {
            try { soap(d, "Stop", "<InstanceID>0</InstanceID>"); } catch (Exception ignored) {}
        });
    }
}
