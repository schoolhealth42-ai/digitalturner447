package com.dtvradio.tuner;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;
import java.util.List;

public class MainActivity extends Activity implements AudioPlayer.Listener {
    static final String[] TABS = {"📺\nتلفاز", "📻\nراديو", "📚\nمكتبتي", "⚙️\nالإعدادات"};
    static final int TAB_TV = 0, TAB_RADIO = 1, TAB_LIB = 2, TAB_SETTINGS = 3;

    private FrameLayout content;
    private final Button[] tabBtns = new Button[TABS.length];
    private TvPanel tv;
    private RadioPanel radio;
    private LibraryPanel library;
    private SettingsPanel settings;
    private int currentTab = -1;

    private LinearLayout miniBar;
    private TextView miniTitle, miniStatus;
    private Button miniBtn;
    private TextView rcvBadge;

    private void updateRcvBadge() {
        if (rcvBadge == null) return;
        boolean on = Prefs.receiverMode(this);
        rcvBadge.setVisibility(on ? View.VISIBLE : View.GONE);
        rcvBadge.setText(DlnaRenderer.isRunning() ? "📡 جاهز للاستقبال" : "📡 يبدأ…");
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Ui.applyTheme(this);
        Net.init(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.CARD);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        // header with a time-of-day greeting
        LinearLayout header = Ui.row(this);
        int p = Ui.dp(this, 16);
        header.setPadding(p, Ui.dp(this, 12), p, Ui.dp(this, 6));
        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(Ui.text(this, greeting(), 13, Ui.SUB, false));
        titles.addView(Ui.text(this, "الموالف الرقمي", 22, Ui.TEXT, true));
        titles.addView(Ui.text(this, "تلفاز وراديو من كل دول العالم", 13, Ui.ACCENT, false));
        header.addView(titles, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        rcvBadge = Ui.text(this, "📡 جاهز للاستقبال", 12, Ui.DARK_TEXT, true);
        rcvBadge.setBackground(Ui.round(this, Ui.GREEN, 12));
        rcvBadge.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4));
        rcvBadge.setVisibility(View.GONE);
        rcvBadge.setOnClickListener(v -> showTab(TAB_SETTINGS));
        header.addView(rcvBadge);
        root.addView(header);

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        // mini player: visible on other tabs while the radio plays
        miniBar = Ui.row(this);
        miniBar.setBackground(Ui.round(this, Ui.CARD2, 14));
        miniBar.setPadding(Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 8), Ui.dp(this, 6));
        LinearLayout mcol = new LinearLayout(this);
        mcol.setOrientation(LinearLayout.VERTICAL);
        miniTitle = Ui.text(this, "", 14, Ui.TEXT, true);
        miniTitle.setSingleLine(true);
        miniTitle.setEllipsize(TextUtils.TruncateAt.END);
        miniStatus = Ui.text(this, "", 12, Ui.SUB, false);
        miniStatus.setSingleLine(true);
        mcol.addView(miniTitle);
        mcol.addView(miniStatus);
        miniBar.addView(mcol, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        miniBtn = Ui.button(this, "⏹", Ui.ACCENT);
        miniBtn.setOnClickListener(v -> {
            AudioPlayer pl = AudioPlayer.get();
            if (pl.isActive()) pl.stop(); else pl.replay(this);
        });
        miniBar.addView(miniBtn, Ui.wrap(this, 2));
        miniBar.setOnClickListener(v -> showTab(TAB_RADIO));
        miniBar.setVisibility(View.GONE);
        LinearLayout.LayoutParams mp = Ui.full(this, 0);
        int m = Ui.dp(this, 8);
        mp.setMargins(m, m / 2, m, m / 2);
        root.addView(miniBar, mp);

        LinearLayout bar = Ui.row(this);
        bar.setBackgroundColor(Ui.CARD);
        bar.setPadding(Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4), Ui.dp(this, 4));
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            Button t = Ui.button(this, TABS[i], Ui.CARD);
            t.setTextSize(12.5f * Ui.SCALE);
            t.setGravity(Gravity.CENTER);
            t.setOnClickListener(v -> showTab(idx));
            tabBtns[i] = t;
            bar.addView(t, Ui.weight(this, 1, 2));
        }
        root.addView(bar);
        setContentView(root);

        AudioPlayer.get().addListener(this);
        if (Prefs.receiverMode(this)) DlnaRenderer.start(this);

        int start = Prefs.startTab(this);
        if (start < 0) start = Prefs.lastTab(this);
        if (getIntent() != null && getIntent().hasExtra("tab")) start = getIntent().getIntExtra("tab", start);
        showTab(start);

        updateRcvBadge();
        rcvBadge.postDelayed(this::updateRcvBadge, 2500);
        askNotificationPermission();
        maybeAutoResume(b);
        updateMini();
    }

    private String greeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        if (h >= 4 && h < 12) return "☀️ صباح الخير";
        if (h >= 12 && h < 17) return "🌤 مساء الخير";
        return "🌙 مساء الخير";
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && Prefs.bgPlayback(this)
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != android.content.pm.PackageManager.PERMISSION_GRANTED
                && !Prefs.p(this).getBoolean("asked_notif", false)) {
            Prefs.edit(this).putBoolean("asked_notif", true).apply();
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 77);
        }
    }

    private void maybeAutoResume(Bundle saved) {
        if (saved != null || !Prefs.autoResume(this) || AudioPlayer.get().isActive()) return;
        List<Station> h = History.load(this, "radio");
        if (h.isEmpty()) return;
        playRadio(h.get(0));
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (intent != null && intent.hasExtra("tab")) showTab(intent.getIntExtra("tab", TAB_RADIO));
    }

    void showTab(int i) {
        if (i < 0 || i >= TABS.length) i = TAB_TV;
        currentTab = i;
        Prefs.edit(this).putInt("tab", i).apply();
        for (int k = 0; k < tabBtns.length; k++) {
            tabBtns[k].setBackground(Ui.round(this, k == i ? Ui.CARD2 : Ui.CARD, 12));
            tabBtns[k].setTextColor(k == i ? Ui.ACCENT : Ui.SUB);
        }
        View v;
        switch (i) {
            case TAB_TV:
                if (tv == null) tv = new TvPanel(this);
                tv.onShown();
                v = tv;
                break;
            case TAB_LIB:
                if (library == null) library = new LibraryPanel(this);
                library.onShown();
                v = library;
                break;
            case TAB_SETTINGS:
                if (settings == null) settings = new SettingsPanel(this);
                settings.onShown();
                v = settings;
                break;
            default:
                if (radio == null) radio = new RadioPanel(this);
                radio.onShown();
                v = radio;
                break;
        }
        content.removeAllViews();
        content.addView(v, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        v.setAlpha(0f);
        v.animate().alpha(1f).setDuration(180).start();
        updateMini();
    }

    /** Plays a radio station from anywhere in the app and shows the radio dial. */
    void playRadio(Station s) {
        AudioPlayer.get().play(this, s);
        showTab(TAB_RADIO);
        if (radio != null) radio.showStation(s);
    }

    // ---- mini player ----

    @Override
    public void onPlayerStatus(String status, boolean playing) {
        updateMini();
    }

    private void updateMini() {
        if (miniBar == null) return;
        AudioPlayer pl = AudioPlayer.get();
        Station s = pl.current();
        boolean show = s != null && pl.isActive() && currentTab != TAB_RADIO;
        miniBar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (!show) return;
        miniTitle.setText("📻 " + s.name);
        int left = pl.sleepMinutesLeft();
        miniStatus.setText(pl.lastStatus() + (left > 0 ? "  •  ⏾ " + left + " د" : ""));
        miniBtn.setText(pl.isActive() ? "⏹" : "▶");
    }

    /** what: "theme" (rebuild UI), "tv", "radio", "net", "all". */
    void onSettingsChanged(String what) {
        switch (what) {
            case "theme":
                recreate();
                return;
            case "receiver":
                if (Prefs.receiverMode(this)) {
                    DlnaRenderer.start(this);
                    android.widget.Toast.makeText(this, "📡 وضع الاستقبال يعمل — أرسل القنوات من جوالك الآن", android.widget.Toast.LENGTH_LONG).show();
                } else {
                    DlnaRenderer.stop();
                }
                updateRcvBadge();
                return;
            case "net":
                Net.init(this);
                return;
            case "tv":
                if (tv != null) tv.reload();
                return;
            case "radio":
                if (radio != null) radio.reload();
                return;
            default:
                Net.init(this);
                if (tv != null) tv.reload();
                if (radio != null) radio.reload();
        }
    }

    @Override
    public void onBackPressed() {
        int home = Prefs.startTab(this) < 0 ? TAB_TV : Prefs.startTab(this);
        if (currentTab != home) {
            showTab(home);
            return;
        }
        // keep the radio playing in the background instead of closing
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        AudioPlayer.get().clearListeners();
        if (isFinishing() && !Prefs.bgPlayback(this)) AudioPlayer.get().stop();
        super.onDestroy();
    }
}
