package com.dtvradio.tuner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.source.MediaSource;
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Live TV player built on ExoPlayer, tuned for medium and weak internet:
 *  - adaptive HLS that starts from a low bitrate estimate
 *  - quality modes: auto / low / medium / high / audio-only
 *  - larger buffer, automatic retries, and automatic quality drop when it keeps stalling
 *  - next / previous channel without leaving the player
 */
public class PlayerActivity extends Activity {
    public static List<Station> playlist = new ArrayList<>();
    public static int index = 0;

    static final String[] QUALITY = {"تلقائي", "منخفضة — نت ضعيف", "متوسطة", "عالية", "صوت فقط — أضعف نت"};
    static final String[] QUALITY_SHORT = {"تلقائي", "منخفضة", "متوسطة", "عالية", "صوت فقط"};
    static final int MAX_RETRIES = 5;
    static final long STALL_MS = 12000;

    private final Handler h = new Handler(Looper.getMainLooper());
    private ExoPlayer player;
    private PlayerView view;
    private LinearLayout topBar;
    private TextView title, status;
    private Button qBtn;
    private int quality;
    private boolean autoDowngraded;
    private int retries;
    private Button castBtn;

    /** The open player, so receiver mode (DLNA) can pause / close / resume it. */
    static java.lang.ref.WeakReference<PlayerActivity> current = new java.lang.ref.WeakReference<>(null);

    // ---- live translation of captions (CC) to Arabic ----
    private boolean trOn;
    private Button trBtn;
    private TextView subTv;
    private String channelLang = null;     // detected / chosen source language for this channel
    private boolean detecting = false;
    private String latestCue = "";
    private boolean hasTextTrack = false;
    private boolean gotCue = false;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        current = new java.lang.ref.WeakReference<>(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_FULLSCREEN);
        AudioPlayer.get().stop();
        quality = Prefs.effectiveQuality(this);

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        view = new PlayerView(this);
        view.setShowBuffering(PlayerView.SHOW_BUFFERING_WHEN_PLAYING);
        view.setKeepScreenOn(true);
        root.addView(view, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        // top overlay: title + channel switch + quality
        topBar = Ui.row(this);
        topBar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        topBar.setBackgroundColor(0x99000000);
        int p = Ui.dp(this, 8);
        topBar.setPadding(p * 2, p, p * 2, p);
        title = Ui.text(this, "", 16, 0xFFFFFFFF, true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        topBar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button pip = smallBtn("⧉");
        Button prev = smallBtn("⏮");
        Button next = smallBtn("⏭");
        qBtn = smallBtn("");
        qBtn.setBackground(Ui.round(this, Ui.ACCENT, 10));
        qBtn.setTextColor(Ui.DARK_TEXT);
        if (Build.VERSION.SDK_INT >= 26) topBar.addView(pip, Ui.wrap(this, 3));
        topBar.addView(prev, Ui.wrap(this, 3));
        topBar.addView(next, Ui.wrap(this, 3));
        topBar.addView(qBtn, Ui.wrap(this, 3));
        trBtn = smallBtn("🌐 ترجمة");
        topBar.addView(trBtn, Ui.wrap(this, 3));
        castBtn = smallBtn("📡 عرض");
        topBar.addView(castBtn, Ui.wrap(this, 3));
        root.addView(topBar, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        status = Ui.text(this, "", 15, 0xFFFFFFFF, false);
        status.setGravity(Gravity.CENTER);
        status.setBackground(Ui.round(this, 0xAA000000, 12));
        status.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        status.setVisibility(View.GONE);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        sp.bottomMargin = Ui.dp(this, 70);
        root.addView(status, sp);

        // translated captions overlay
        subTv = Ui.text(this, "", 19, 0xFFFFFFFF, true);
        subTv.setGravity(Gravity.CENTER);
        subTv.setShadowLayer(6f, 0f, 2f, 0xFF000000);
        subTv.setBackground(Ui.round(this, 0x99000000, 10));
        subTv.setPadding(Ui.dp(this, 14), Ui.dp(this, 6), Ui.dp(this, 14), Ui.dp(this, 6));
        subTv.setVisibility(View.GONE);
        FrameLayout.LayoutParams subLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        subLp.bottomMargin = Ui.dp(this, 24);
        subLp.leftMargin = subLp.rightMargin = Ui.dp(this, 24);
        root.addView(subTv, subLp);

        setContentView(root);
        trOn = Prefs.trCaptions(this);

        pip.setOnClickListener(v -> enterPip());
        prev.setOnClickListener(v -> switchChannel(-1));
        next.setOnClickListener(v -> switchChannel(1));
        qBtn.setOnClickListener(v -> chooseQuality());
        trBtn.setOnClickListener(v -> toggleTranslation());
        castBtn.setOnClickListener(v -> {
            if (CastManager.isCasting()) {
                CastManager.stopCasting(this);
                if (player != null) player.setPlayWhenReady(true);
            } else if (playlist != null && !playlist.isEmpty()) {
                CastManager.showDevices(this, playlist.get(Math.max(0, Math.min(index, playlist.size() - 1))), true);
            }
        });
        CastManager.setListener(this::onCastChanged);
        view.setControllerVisibilityListener((PlayerView.ControllerVisibilityListener) visibility ->
                topBar.setVisibility(visibility == View.VISIBLE ? View.VISIBLE : View.GONE));

        buildPlayer();
        playCurrent();
        hideSystemUi();
    }

    private Button smallBtn(String s) {
        Button b = Ui.button(this, s, 0x33FFFFFF);
        b.setTextSize(13);
        b.setTextColor(0xFFFFFFFF);
        b.setMinimumHeight(Ui.dp(this, 36));
        return b;
    }

    // ---------------- player ----------------

    /** Rough first guess of the connection speed so playback starts at a sensible bitrate. */
    private long initialBitrate() {
        long def = 700_000L;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null || Build.VERSION.SDK_INT < 23) return def;
            Network n = cm.getActiveNetwork();
            NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
            if (nc == null) return def;
            long kbps = nc.getLinkDownstreamBandwidthKbps();
            if (kbps <= 0) return def;
            long est = kbps * 1000L / 3;   // be conservative
            return Math.max(300_000L, Math.min(est, 4_000_000L));
        } catch (Exception e) {
            return def;
        }
    }

    private void buildPlayer() {
        DefaultBandwidthMeter meter = new DefaultBandwidthMeter.Builder(this)
                .setInitialBitrateEstimate(initialBitrate())
                .build();
        // bigger buffer than default: survives short drops on weak connections
        DefaultLoadControl load = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(20_000, 60_000, 2_000, 5_000)
                .build();
        player = new ExoPlayer.Builder(this)
                .setBandwidthMeter(meter)
                .setLoadControl(load)
                .build();
        view.setPlayer(player);
        applyQuality(quality);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) {
                    retries = 0;
                    h.removeCallbacks(stallCheck);
                    status.setVisibility(View.GONE);
                } else if (state == Player.STATE_BUFFERING) {
                    h.removeCallbacks(stallCheck);
                    h.postDelayed(stallCheck, STALL_MS);
                }
            }

            @Override
            public void onCues(androidx.media3.common.text.CueGroup cueGroup) {
                handleCues(cueGroup);
            }

            @Override
            public void onTracksChanged(androidx.media3.common.Tracks tracks) {
                hasTextTrack = tracks.containsType(C.TRACK_TYPE_TEXT);
                if (trOn && !tracks.isEmpty() && !hasTextTrack) {
                    showStatus("🌐 هذه القناة لا ترسل نصوصاً مرافقة (CC)، لذلك لا يمكن ترجمتها");
                    h.postDelayed(() -> status.setVisibility(View.GONE), 5000);
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                handleError(error);
            }
        });
    }

    /** Keeps buffering too long -> drop to low quality automatically. */
    private final Runnable stallCheck = new Runnable() {
        @Override public void run() {
            if (player == null || player.getPlaybackState() != Player.STATE_BUFFERING) return;
            if ((quality == 0 || quality == 2 || quality == 3) && !autoDowngraded) {
                autoDowngraded = true;
                applyQuality(1);
                showStatus("الاتصال بطيء — تم تخفيض الجودة تلقائياً ⚡");
                updateQualityLabel();
            } else if (quality != 4 && autoDowngraded) {
                showStatus("الاتصال ضعيف جداً — جرّب «صوت فقط» من زر الجودة");
            }
        }
    };

    private void applyQuality(int q) {
        if (player == null) return;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, q == 4)
                .setForceLowestBitrate(q == 1)
                .clearVideoSizeConstraints()
                .setMaxVideoBitrate(Integer.MAX_VALUE)
                // captions are needed only when translating them
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, !trOn)
                .setPreferredTextLanguages("en", "fr", "es", "de", "tr", "pt", "it", "ru")
                .setSelectUndeterminedTextLanguage(true);
        if (q == 1) {
            b.setMaxVideoSize(640, 360).setMaxVideoBitrate(700_000);
        } else if (q == 2) {
            b.setMaxVideoSize(854, 480).setMaxVideoBitrate(1_500_000);
        }
        player.setTrackSelectionParameters(b.build());
    }

    private void updateQualityLabel() {
        String l = autoDowngraded ? "منخفضة ⚡" : QUALITY_SHORT[quality];
        qBtn.setText("⚙ " + l);
    }

    private void chooseQuality() {
        new AlertDialog.Builder(this)
                .setTitle("جودة البث")
                .setSingleChoiceItems(QUALITY, quality, (d, which) -> {
                    quality = which;
                    autoDowngraded = false;
                    Prefs.edit(this).putInt("quality", which).apply();
                    applyQuality(which);
                    updateQualityLabel();
                    if (player != null && player.getPlayerError() != null) {
                        player.prepare();
                    }
                    d.dismiss();
                })
                .show();
    }

    private void playCurrent() {
        if (playlist == null || playlist.isEmpty()) {
            finish();
            return;
        }
        if (index < 0) index = playlist.size() - 1;
        if (index >= playlist.size()) index = 0;
        Station s = playlist.get(index);
        retries = 0;
        autoDowngraded = false;
        applyQuality(quality);
        updateQualityLabel();
        title.setText(s.name);
        status.setVisibility(View.GONE);
        History.add(this, "tv", s);
        channelLang = Prefs.trSource(this).isEmpty() ? null : Prefs.trSource(this);
        detecting = false;
        latestCue = "";
        gotCue = false;
        subTv.setVisibility(View.GONE);
        updateTrButton();
        if (castBtn != null) onCastChanged(CastManager.activeName());
        h.removeCallbacks(stallCheck);

        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(s.ua != null && !s.ua.isEmpty() ? s.ua
                        : "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15_000)
                .setReadTimeoutMs(20_000);
        if (s.referer != null && !s.referer.isEmpty()) {
            Map<String, String> hdr = new HashMap<>();
            hdr.put("Referer", s.referer);
            http.setDefaultRequestProperties(hdr);
        }
        MediaItem.Builder mb = new MediaItem.Builder().setUri(s.url);
        if (s.url.toLowerCase(Locale.ROOT).contains(".m3u8")) mb.setMimeType(MimeTypes.APPLICATION_M3U8);
        MediaSource src = new DefaultMediaSourceFactory(http).createMediaSource(mb.build());
        player.setMediaSource(src);
        player.prepare();
        player.setPlayWhenReady(true);
    }

    private void handleError(PlaybackException e) {
        if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
            player.seekToDefaultPosition();
            player.prepare();
            return;
        }
        boolean network = e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED
                || e.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                || e.errorCode == PlaybackException.ERROR_CODE_TIMEOUT
                || e.errorCode == PlaybackException.ERROR_CODE_IO_UNSPECIFIED;
        boolean deadLink = e.errorCode == PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS
                || e.errorCode == PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND
                || e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED
                || e.errorCode == PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED;
        int limit = deadLink ? 1 : MAX_RETRIES;
        if (retries < limit) {
            retries++;
            if (retries >= 2 && !autoDowngraded && (quality == 0 || quality == 2 || quality == 3)) {
                autoDowngraded = true;
                applyQuality(1);
                updateQualityLabel();
            }
            showStatus((network ? "الاتصال ضعيف" : "خطأ في البث") + " — إعادة المحاولة " + retries + "/" + limit + "…");
            h.postDelayed(() -> {
                if (player != null) player.prepare();
            }, 1500L * retries);
        } else {
            showStatus(deadLink
                    ? "هذه القناة متوقفة أو محجوبة في منطقتك — اضغط ⏭ للقناة التالية"
                    : "تعذّر التشغيل بسبب ضعف الاتصال — جرّب جودة «منخفضة» أو «صوت فقط»");
            topBar.setVisibility(View.VISIBLE);
            view.showController();
        }
    }

    private void showStatus(String s) {
        status.setText(s);
        status.setVisibility(View.VISIBLE);
    }

    // ---------------- casting & receiver-mode hooks ----------------

    private void onCastChanged(String device) {
        boolean on = device != null;
        castBtn.setText(on ? "📡 إيقاف العرض" : "📡 عرض");
        castBtn.setBackground(Ui.round(this, on ? Ui.ACCENT2 : 0x33FFFFFF, 10));
        castBtn.setTextColor(on ? Ui.DARK_TEXT : 0xFFFFFFFF);
        if (on) {
            if (Prefs.castPauseLocal(this) && player != null) player.setPlayWhenReady(false);
            showStatus("📡 يُعرض الآن على: " + device + "\nتحكّم بالصوت من التلفاز، واضغط «إيقاف العرض» للرجوع");
        } else {
            status.setVisibility(View.GONE);
        }
    }

    static void remotePause() {
        PlayerActivity p = current.get();
        if (p != null && p.player != null) p.player.setPlayWhenReady(false);
    }

    static void remoteClose() {
        PlayerActivity p = current.get();
        if (p != null) p.finish();
    }

    /** Resumes if the same stream is already open; returns false if the player must be (re)opened. */
    static boolean remoteResumeIfSame(String url) {
        PlayerActivity p = current.get();
        if (p == null || p.player == null || playlist == null || playlist.isEmpty()) return false;
        Station s = playlist.get(Math.max(0, Math.min(index, playlist.size() - 1)));
        if (!s.url.equals(url)) return false;
        p.player.setPlayWhenReady(true);
        return true;
    }

    /** Remote control keys (satellite receivers, Android TV boxes, TV remotes). */
    @Override
    public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        switch (keyCode) {
            case android.view.KeyEvent.KEYCODE_CHANNEL_UP:
            case android.view.KeyEvent.KEYCODE_MEDIA_NEXT:
            case android.view.KeyEvent.KEYCODE_PAGE_UP:
                switchChannel(1);
                return true;
            case android.view.KeyEvent.KEYCODE_CHANNEL_DOWN:
            case android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS:
            case android.view.KeyEvent.KEYCODE_PAGE_DOWN:
                switchChannel(-1);
                return true;
            case android.view.KeyEvent.KEYCODE_INFO:
            case android.view.KeyEvent.KEYCODE_MENU:
                view.showController();
                topBar.setVisibility(View.VISIBLE);
                return true;
            case android.view.KeyEvent.KEYCODE_PROG_RED:
                toggleTranslation();
                return true;
            default:
                return super.onKeyDown(keyCode, event);
        }
    }

    private void switchChannel(int dir) {
        if (playlist == null || playlist.size() < 2) {
            Toast.makeText(this, "لا توجد قنوات أخرى في هذه القائمة", Toast.LENGTH_SHORT).show();
            return;
        }
        index += dir;
        h.removeCallbacksAndMessages(null);
        if (player != null) player.stop();
        playCurrent();
    }

    // ---------------- translation of captions ----------------

    private void updateTrButton() {
        trBtn.setText(trOn ? "🌐 ترجمة ✓" : "🌐 ترجمة");
        trBtn.setBackground(Ui.round(this, trOn ? Ui.GREEN : 0x33FFFFFF, 10));
        trBtn.setTextColor(trOn ? Ui.DARK_TEXT : 0xFFFFFFFF);
        if (view.getSubtitleView() != null) {
            // our translated overlay replaces the original captions
            view.getSubtitleView().setVisibility(trOn ? View.GONE : View.VISIBLE);
        }
    }

    private void toggleTranslation() {
        trOn = !trOn;
        updateTrButton();
        applyQuality(autoDowngraded ? 1 : quality);
        if (!trOn) {
            subTv.setVisibility(View.GONE);
            return;
        }
        String src = channelLang != null ? channelLang : "en";
        showStatus("🌐 جارِ تجهيز الترجمة إلى العربية…");
        Tr.prepare(this, src, ok -> {
            if (ok == null) {
                showStatus("تعذّر تنزيل حزمة الترجمة — تحقق من الإنترنت" + (Prefs.trWifiOnly(this) ? " أو اتصل بشبكة واي فاي" : ""));
            } else {
                showStatus("🌐 الترجمة جاهزة — ستظهر عند وصول نصوص القناة");
                h.postDelayed(() -> { if (!gotCue) status.setVisibility(View.GONE); }, 4000);
                h.postDelayed(() -> {
                    if (trOn && !gotCue && player != null && player.isPlaying()) {
                        showStatus("🌐 لم تصل نصوص مرافقة من هذه القناة بعد — الترجمة تعمل فقط مع القنوات التي تبث نصاً (CC)");
                        h.postDelayed(() -> status.setVisibility(View.GONE), 6000);
                    }
                }, 25000);
            }
        });
    }

    private final Runnable cueRun = new Runnable() {
        @Override public void run() { translateCue(latestCue); }
    };

    private void handleCues(androidx.media3.common.text.CueGroup g) {
        if (!trOn) return;
        StringBuilder sb = new StringBuilder();
        for (androidx.media3.common.text.Cue c : g.cues) {
            if (c.text == null) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(c.text.toString().replace('\n', ' ').trim());
        }
        String text = sb.toString().trim();
        if (text.isEmpty()) {
            h.removeCallbacks(cueRun);
            h.postDelayed(() -> { if (latestCue.isEmpty()) subTv.setVisibility(View.GONE); }, 1500);
            latestCue = "";
            return;
        }
        gotCue = true;
        latestCue = text;
        // captions often arrive word by word: wait a moment so whole phrases are translated
        h.removeCallbacks(cueRun);
        h.postDelayed(cueRun, 350);
    }

    private void translateCue(final String text) {
        if (text.isEmpty()) return;
        if (channelLang == null) {
            if (!detecting && text.length() >= 20) {
                detecting = true;
                Tr.detect(text, lang -> {
                    detecting = false;
                    channelLang = lang != null ? lang : "en";
                    translateCue(latestCue);
                });
                return;
            }
            if (detecting) return;
        }
        final String src = channelLang != null ? channelLang : "en";
        Tr.translate(this, src, text, result -> {
            if (!trOn || result == null) return;
            if (!text.equals(latestCue) && !latestCue.startsWith(text)) return;   // outdated line
            String shown = Prefs.trShowOriginal(this) && !src.equals("ar") ? result + "\n" + text : result;
            subTv.setText(shown);
            subTv.setVisibility(View.VISIBLE);
        });
    }

    // ---------------- picture-in-picture ----------------

    private boolean inPip = false;

    private void enterPip() {
        if (Build.VERSION.SDK_INT < 26) return;
        try {
            enterPictureInPictureMode(new android.app.PictureInPictureParams.Builder()
                    .setAspectRatio(new android.util.Rational(16, 9)).build());
        } catch (Exception e) {
            Toast.makeText(this, "صورة داخل صورة غير مدعومة على هذا الجهاز", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        if (Prefs.autoPip(this) && player != null && player.isPlaying()) enterPip();
    }

    @Override
    public void onPictureInPictureModeChanged(boolean isInPip, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(isInPip, cfg);
        inPip = isInPip;
        view.setUseController(!isInPip);
        topBar.setVisibility(isInPip ? View.GONE : View.VISIBLE);
        if (isInPip) status.setVisibility(View.GONE);
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        h.removeCallbacksAndMessages(null);
        if (player != null) player.stop();
        playCurrent();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (player != null) player.setPlayWhenReady(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (player != null) player.setPlayWhenReady(false);
        if (inPip) finish();   // the PiP window was closed
    }

    @Override
    protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        CastManager.setListener(null);
        if (current.get() == this) current = new java.lang.ref.WeakReference<>(null);
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }
}
