package com.dtvradio.tuner;

import android.content.Context;

import java.util.ArrayList;
import java.util.List;

/** Recently watched channels ("tv") and recently heard stations ("radio"). */
public final class History {
    private History() {}
    static final int MAX = 40;

    public static void add(Context c, String key, Station s) {
        List<Station> l = Favorites.load(c, "hist_" + key);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).url.equals(s.url)) l.remove(i);
        l.add(0, s);
        while (l.size() > MAX) l.remove(l.size() - 1);
        Favorites.save(c, "hist_" + key, l);
    }

    public static List<Station> load(Context c, String key) {
        return Favorites.load(c, "hist_" + key);
    }

    public static void remove(Context c, String key, String url) {
        List<Station> l = Favorites.load(c, "hist_" + key);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).url.equals(url)) l.remove(i);
        Favorites.save(c, "hist_" + key, l);
    }

    public static void clear(Context c) {
        Favorites.save(c, "hist_tv", new ArrayList<Station>());
        Favorites.save(c, "hist_radio", new ArrayList<Station>());
    }
}
